# PlanAura – AI-Assisted Floor Plan & Vastu Design App

A cross-platform mobile application (Android/iOS) built with React Native and Expo, featuring a 2D floor plan designer with Vastu/Energy-based feedback, smart suggestions, and cost estimation.

## Overview

PlanAura helps users design floor plans with intelligent guidance based on Vastu principles and energy balance. The app provides real-time feedback on room placements, generates cost estimates, and exports comprehensive reports.

### Key Features

- **2D Floor Plan Designer**: Grid-based canvas with room creation, positioning, and sizing
- **Room Management**: Add, edit, delete rooms with type selection (Bedroom, Kitchen, Bathroom, Living Room, Office)
- **Direction & Compass System**: Automatic direction calculation and visual compass overlay
- **Vastu Rule Engine**: Rule-based analysis with energy scoring (0-100)
- **Smart Suggestions**: Dynamic suggestions for optimal room placement
- **Cost Estimation**: Multi-tier cost calculator with breakdown (Basic/Standard/Premium)
- **Plan Reports**: Generate JSON reports with summary and analysis
- **Backend Integration**: Express.js API with MongoDB for data persistence

## Project Structure

```
planaura-app/
├── app/
│   ├── (tabs)/
│   │   ├── _layout.tsx          # Tab navigation setup
│   │   ├── index.tsx            # Home screen
│   │   └── designer.tsx         # Floor plan designer screen
│   └── _layout.tsx              # Root layout with providers
├── components/
│   ├── floor-plan-canvas.tsx    # SVG canvas for floor plan
│   ├── room-properties-panel.tsx # Room editing panel
│   ├── vastu-analysis-panel.tsx # Vastu analysis display
│   ├── cost-estimation-panel.tsx# Cost breakdown display
│   └── screen-container.tsx     # SafeArea wrapper
├── lib/
│   ├── store.ts                 # Zustand state management
│   ├── vastu-engine.ts          # Vastu rule engine
│   ├── cost-calculator.ts       # Cost estimation logic
│   ├── report-generator.ts      # Report generation
│   └── utils.ts                 # Utility functions
├── server/
│   ├── db.ts                    # Database query helpers
│   ├── routers.ts               # tRPC API routes
│   └── storage.ts               # File storage helpers
├── drizzle/
│   ├── schema.ts                # Database schema (Plans, Rooms)
│   └── relations.ts             # Table relationships
├── shared/
│   ├── types.ts                 # Shared TypeScript types
│   └── const.ts                 # Shared constants
├── hooks/
│   ├── use-colors.ts            # Theme colors hook
│   ├── use-color-scheme.ts      # Dark/light mode detection
│   └── use-auth.ts              # Authentication hook
├── assets/
│   └── images/
│       ├── icon.png             # App icon (1024x1024)
│       ├── splash-icon.png      # Splash screen icon
│       └── favicon.png          # Web favicon
├── app.config.ts                # Expo configuration
├── tailwind.config.js           # Tailwind CSS config
├── theme.config.js              # Theme color tokens
├── package.json                 # Dependencies
└── README_PLANAURA.md           # This file
```

## Tech Stack

### Frontend
- **React Native 0.81** with Expo SDK 54
- **React 19** with TypeScript
- **NativeWind 4** (Tailwind CSS for React Native)
- **react-native-svg** (SVG rendering)
- **Zustand** (State management)
- **react-native-gesture-handler** (Touch interactions)

### Backend
- **Node.js + Express** (REST API)
- **tRPC** (Type-safe API)
- **Drizzle ORM** (Database abstraction)
- **MySQL** (Database)

### Build & Deploy
- **Expo** (Build and deployment)
- **Metro** (React Native bundler)
- **TypeScript** (Type safety)

## Installation & Setup

### Prerequisites
- Node.js 18+ and npm/pnpm
- Expo CLI: `npm install -g expo-cli`
- Android Studio or Xcode (for native development)

### Local Development

1. **Install dependencies**:
   ```bash
   cd planaura-app
   pnpm install
   ```

2. **Set up environment variables**:
   Create a `.env` file in the project root:
   ```
   DATABASE_URL=mysql://user:password@localhost:3306/planaura
   EXPO_PORT=8081
   ```

3. **Run database migrations**:
   ```bash
   pnpm db:push
   ```

4. **Start development server**:
   ```bash
   pnpm dev
   ```
   This starts both the Metro bundler and Express backend.

5. **Open in Expo Go**:
   - iOS: Scan QR code with Camera app
   - Android: Scan QR code with Expo Go app
   - Web: Open the Metro URL in browser

### Testing

Run tests with:
```bash
pnpm test
```

## Core Modules

### Vastu Engine (`lib/vastu-engine.ts`)

The Vastu rule engine analyzes floor plans based on traditional Vastu principles:

**Preferred Directions**:
- Kitchen → SE (South-East)
- Bedroom → SW (South-West)
- Living Room → N/E (North/East)
- Office → N/E (North/East)
- Bathroom → NW (North-West)

**Scoring**:
- Energy Score: 0-100
- Deductions: High severity issues (-15), Medium (-10), Low (-5)
- Bonuses: +5 per positive placement

### Cost Calculator (`lib/cost-calculator.ts`)

Multi-tier cost estimation with breakdown:

**Cost Tiers**:
- Basic: ₹1,500/sqft
- Standard: ₹2,000/sqft
- Premium: ₹3,000/sqft

**Breakdown**:
- Structure: 50%
- Interiors: 20%
- Electrical: 15%
- Plumbing: 15%

### State Management (`lib/store.ts`)

Zustand store manages:
- Current floor plan (rooms, metadata)
- Canvas state (zoom, pan)
- Selected room
- UI state

## API Endpoints

### Plans
- `POST /api/plans.create` - Create new plan
- `GET /api/plans.getWithRooms` - Get plan with rooms
- `GET /api/plans.listByUser` - List user's plans
- `PUT /api/plans.update` - Update plan
- `DELETE /api/plans.delete` - Delete plan

### Rooms
- `POST /api/rooms.create` - Create room
- `GET /api/rooms.listByPlan` - Get plan's rooms
- `GET /api/rooms.getById` - Get specific room
- `PUT /api/rooms.update` - Update room
- `DELETE /api/rooms.delete` - Delete room

## Data Structures

### Plan
```typescript
interface Plan {
  id: string;
  name: string;
  rooms: Room[];
  totalArea: number;
  vastuScore: number;
  costEstimate: number;
  costTier: "basic" | "standard" | "premium";
  createdAt: Date;
  updatedAt: Date;
}
```

### Room
```typescript
interface Room {
  id: string;
  type: "bedroom" | "kitchen" | "bathroom" | "living_room" | "office";
  x: number;
  y: number;
  width: number;
  height: number;
  direction: "N" | "NE" | "E" | "SE" | "S" | "SW" | "W" | "NW";
  area: number;
}
```

## UI/UX Design

### Color Scheme
- **Primary**: Teal/Cyan (#0a7ea4)
- **Success**: Green (#22c55e)
- **Warning**: Yellow (#f59e0b)
- **Error**: Red (#ef4444)
- **Background**: White (#ffffff) / Dark (#151718)

### Room Type Colors
- Bedroom: Blue (#3b82f6)
- Kitchen: Orange (#f97316)
- Bathroom: Green (#10b981)
- Living Room: Purple (#a855f7)
- Office: Gray (#6b7280)

### Layout Principles
- Portrait orientation (9:16) for mobile
- One-handed usage with bottom-aligned controls
- Floating Action Buttons (FAB) for primary actions
- Bottom panels for secondary controls
- Minimalist design with clear hierarchy

## Future Enhancements

- 3D floor plan preview
- AR house visualization
- AI-powered layout optimization (OpenAI integration)
- Architect marketplace
- Advanced Vastu/Feng Shui dataset
- Premium subscription features
- Offline support with local caching
- Multi-language support

## Development Guidelines

### Code Style
- Use TypeScript for type safety
- Follow React Native best practices
- Use NativeWind for styling (Tailwind CSS)
- Prefer functional components with hooks
- Keep components small and focused

### Performance
- Optimize SVG rendering for smooth interactions
- Use memoization for expensive calculations
- Lazy load screens and components
- Minimize re-renders with proper state management

### Testing
- Write unit tests for business logic (Vastu engine, cost calculator)
- Test state management with Zustand
- Mock API calls in tests
- Test UI components with React Native Testing Library

## Troubleshooting

### App won't start
- Clear cache: `pnpm expo start --clear`
- Reinstall dependencies: `rm -rf node_modules && pnpm install`
- Check Node version: `node --version` (should be 18+)

### Database connection issues
- Verify DATABASE_URL in .env
- Check MySQL server is running
- Run migrations: `pnpm db:push`

### SVG rendering issues
- Ensure react-native-svg is installed
- Check SVG dimensions and viewBox
- Test on both iOS and Android

## Support & Documentation

- **Expo Documentation**: https://docs.expo.dev
- **React Native Docs**: https://reactnative.dev
- **Drizzle ORM**: https://orm.drizzle.team
- **tRPC**: https://trpc.io

## License

This project is part of the PlanAura MVP and follows the terms specified in the project agreement.

## Contact

For questions or feedback, please reach out to the development team.

---

**Built with ❤️ using React Native, Expo, and modern web technologies.**

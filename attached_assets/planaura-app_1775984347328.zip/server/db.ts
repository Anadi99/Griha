import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, Plan, InsertPlan, plans, Room, InsertRoom, rooms } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============================================================================
// PLANS QUERIES
// ============================================================================

/**
 * Create a new plan
 */
export async function createPlan(data: InsertPlan): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(plans).values(data);
  return (result as any).insertId || 0;
}

/**
 * Get a plan by ID with all its rooms
 */
export async function getPlanWithRooms(planId: number): Promise<{ plan: Plan; rooms: Room[] } | null> {
  const db = await getDb();
  if (!db) return null;

  const planResult = await db.select().from(plans).where(eq(plans.id, planId)).limit(1);
  if (planResult.length === 0) return null;

  const roomResults = await db.select().from(rooms).where(eq(rooms.planId, planId));

  return {
    plan: planResult[0],
    rooms: roomResults,
  };
}

/**
 * Get all plans for a user
 */
export async function getUserPlans(userId: number): Promise<Plan[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(plans).where(eq(plans.userId, userId));
}

/**
 * Update a plan
 */
export async function updatePlan(planId: number, data: Partial<InsertPlan>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(plans).set(data).where(eq(plans.id, planId));
}

/**
 * Delete a plan and all its rooms
 */
export async function deletePlan(planId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Delete all rooms in the plan first
  await db.delete(rooms).where(eq(rooms.planId, planId));
  // Then delete the plan
  await db.delete(plans).where(eq(plans.id, planId));
}

// ============================================================================
// ROOMS QUERIES
// ============================================================================

/**
 * Create a new room in a plan
 */
export async function createRoom(data: InsertRoom): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(rooms).values(data);
  return (result as any).insertId || 0;
}

/**
 * Get all rooms in a plan
 */
export async function getPlanRooms(planId: number): Promise<Room[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(rooms).where(eq(rooms.planId, planId));
}

/**
 * Update a room
 */
export async function updateRoom(roomId: number, data: Partial<InsertRoom>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(rooms).set(data).where(eq(rooms.id, roomId));
}

/**
 * Delete a room
 */
export async function deleteRoom(roomId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(rooms).where(eq(rooms.id, roomId));
}

/**
 * Get a specific room by ID
 */
export async function getRoomById(roomId: number): Promise<Room | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(rooms).where(eq(rooms.id, roomId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import * as db from "./db";

// ============================================================================
// VALIDATION SCHEMAS
// ============================================================================

const createPlanSchema = z.object({
  name: z.string().min(1, "Plan name required").max(255),
  userId: z.number().int().positive(),
});

const updatePlanSchema = z.object({
  planId: z.number().int().positive(),
  name: z.string().min(1).max(255).optional(),
  totalArea: z.number().int().nonnegative().optional(),
  vastuScore: z.number().int().min(0).max(100).optional(),
  costEstimate: z.number().int().nonnegative().optional(),
  costTier: z.enum(["basic", "standard", "premium"]).optional(),
});

const createRoomSchema = z.object({
  planId: z.number().int().positive(),
  roomType: z.enum(["bedroom", "kitchen", "bathroom", "living_room", "office"]),
  x: z.number().int().nonnegative().default(0),
  y: z.number().int().nonnegative().default(0),
  width: z.number().int().positive().default(12),
  height: z.number().int().positive().default(12),
  direction: z.enum(["N", "NE", "E", "SE", "S", "SW", "W", "NW"]).default("N"),
  area: z.number().int().positive().default(144),
});

const updateRoomSchema = z.object({
  roomId: z.number().int().positive(),
  roomType: z.enum(["bedroom", "kitchen", "bathroom", "living_room", "office"]).optional(),
  x: z.number().int().nonnegative().optional(),
  y: z.number().int().nonnegative().optional(),
  width: z.number().int().positive().optional(),
  height: z.number().int().positive().optional(),
  direction: z.enum(["N", "NE", "E", "SE", "S", "SW", "W", "NW"]).optional(),
  area: z.number().int().positive().optional(),
});

// ============================================================================
// MAIN ROUTER
// ============================================================================

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============================================================================
  // PLANS ROUTES
  // ============================================================================
  plans: router({
    /**
     * Create a new plan (guest mode supported)
     */
    create: publicProcedure
      .input(createPlanSchema)
      .mutation(async ({ input }) => {
        const planId = await db.createPlan({
          name: input.name,
          userId: input.userId,
          totalArea: 0,
          vastuScore: 0,
          costEstimate: 0,
          costTier: "standard",
        });
        return { id: planId, name: input.name };
      }),

    /**
     * Get a plan with all its rooms
     */
    getWithRooms: publicProcedure
      .input(z.object({ planId: z.number().int().positive() }))
      .query(async ({ input }) => {
        const result = await db.getPlanWithRooms(input.planId);
        if (!result) {
          throw new Error("Plan not found");
        }
        return result;
      }),

    /**
     * Get all plans for a user
     */
    listByUser: publicProcedure
      .input(z.object({ userId: z.number().int().positive() }))
      .query(async ({ input }) => {
        return db.getUserPlans(input.userId);
      }),

    /**
     * Update a plan
     */
    update: publicProcedure
      .input(updatePlanSchema)
      .mutation(async ({ input }) => {
        const { planId, ...data } = input;
        await db.updatePlan(planId, data);
        return { success: true };
      }),

    /**
     * Delete a plan and all its rooms
     */
    delete: publicProcedure
      .input(z.object({ planId: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await db.deletePlan(input.planId);
        return { success: true };
      }),
  }),

  // ============================================================================
  // ROOMS ROUTES
  // ============================================================================
  rooms: router({
    /**
     * Create a new room in a plan
     */
    create: publicProcedure
      .input(createRoomSchema)
      .mutation(async ({ input }) => {
        const roomId = await db.createRoom({
          planId: input.planId,
          roomType: input.roomType,
          x: input.x,
          y: input.y,
          width: input.width,
          height: input.height,
          direction: input.direction,
          area: input.area,
        });
        return { id: roomId, roomType: input.roomType };
      }),

    /**
     * Get all rooms in a plan
     */
    listByPlan: publicProcedure
      .input(z.object({ planId: z.number().int().positive() }))
      .query(async ({ input }) => {
        return db.getPlanRooms(input.planId);
      }),

    /**
     * Get a specific room by ID
     */
    getById: publicProcedure
      .input(z.object({ roomId: z.number().int().positive() }))
      .query(async ({ input }) => {
        const room = await db.getRoomById(input.roomId);
        if (!room) {
          throw new Error("Room not found");
        }
        return room;
      }),

    /**
     * Update a room
     */
    update: publicProcedure
      .input(updateRoomSchema)
      .mutation(async ({ input }) => {
        const { roomId, ...data } = input;
        await db.updateRoom(roomId, data);
        return { success: true };
      }),

    /**
     * Delete a room
     */
    delete: publicProcedure
      .input(z.object({ roomId: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await db.deleteRoom(input.roomId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;

# PlanAura – Mobile App Interface Design

## Overview

PlanAura is a cross-platform floor plan designer with Vastu/Energy-based feedback and cost estimation. The app is designed for **portrait orientation (9:16)** with **one-handed usage** in mind, following Apple Human Interface Guidelines for iOS-first design.

---

## Screen List

1. **Home Screen** – Main entry point with options to create new plan, browse templates, or load saved plans
2. **Floor Plan Designer** – 2D grid-based canvas for designing rooms with drag, resize, and snap-to-grid
3. **Room Properties Panel** – Side/bottom panel to select room type, view room details
4. **Compass & Direction Overlay** – Visual compass showing cardinal directions (N, NE, E, SE, S, SW, W, NW)
5. **Vastu Analysis Panel** – Displays energy score, issues, and positive confirmations
6. **Smart Suggestions Panel** – Chat-style list of dynamic suggestions with priority levels
7. **Cost Estimation Screen** – Select cost tier (Basic/Standard/Premium), view breakdown
8. **Plan Report Screen** – Summary view with total area, cost, energy score, issues, suggestions
9. **Save/Load Screen** – Browse saved plans, create new, delete, or load existing
10. **Templates Screen** – Browse predefined layouts (1BHK, 2BHK, Small Office)
11. **Settings Screen** – User preferences, guest/login mode

---

## Primary Content and Functionality

### Home Screen
- **Hero Section:** "Design Your Floor Plan" with app logo
- **Quick Actions:**
  - "New Plan" button (primary, floating action button style)
  - "Browse Templates" button
  - "My Plans" button
- **Optional:** Recent plans list (if user has saved plans)
- **Color:** Minimalist white/light background with primary accent color (teal/blue)

### Floor Plan Designer (Main Canvas)
- **Grid Canvas:** 
  - Adjustable grid (e.g., 1ft × 1ft or 0.5m × 0.5m)
  - Snap-to-grid enabled by default
  - Zoom in/out controls (pinch or buttons)
  - Pan/drag to navigate
- **Room Elements:**
  - Rectangular rooms with unique IDs
  - Each room displays: type icon, label, dimensions (e.g., "Bedroom 12×14 ft")
  - Corner handles for resize (visible on tap)
  - Drag to move
- **Compass Overlay:**
  - Fixed compass in top-right corner showing N/S/E/W
  - Visual indicator of room direction (centroid-based)
- **Toolbar:**
  - "Add Room" floating action button (bottom-right)
  - "Undo/Redo" buttons
  - "Delete" button (active when room selected)
  - "Compass" toggle
  - "Suggestions" panel toggle
  - "Cost" panel toggle
  - "Report" button

### Room Properties Panel
- **Room Type Selection:**
  - Buttons: Bedroom, Kitchen, Bathroom, Living Room, Office
  - Color-coded (e.g., Bedroom=Blue, Kitchen=Orange, Bathroom=Green, etc.)
- **Room Details:**
  - Dimensions (width × height in ft or m)
  - Position (x, y coordinates)
  - Direction (auto-calculated, e.g., "SE")
  - Delete button
- **Snap-to-Grid Toggle**

### Compass & Direction Overlay
- **Visual Compass:**
  - Circular compass in top-right, always visible
  - Cardinal directions labeled (N, NE, E, SE, S, SW, W, NW)
  - North always pointing up (fixed orientation)
- **Room Direction Indicator:**
  - Each room shows its calculated direction based on centroid
  - Visual badge on room (e.g., "SE" label)

### Vastu Analysis Panel
- **Energy Score:** Large circular progress indicator (0–100)
- **Status Indicator:**
  - Green: 80–100 (Excellent)
  - Yellow: 50–79 (Good)
  - Red: 0–49 (Needs Improvement)
- **Issues List:**
  - Red icons for violations (e.g., "❌ Bathroom in NE corner")
  - Tap to highlight affected room on canvas
- **Positive Confirmations:**
  - Green icons for correct placements (e.g., "✓ Kitchen in SE")
- **Refresh Button:** Re-calculate score after changes

### Smart Suggestions Panel
- **Chat-Style List:**
  - Each suggestion is a card with:
    - Message (e.g., "Move kitchen to South-East to improve energy balance")
    - Priority badge (High=Red, Medium=Yellow, Low=Gray)
    - "Apply" button (if suggestion is actionable)
- **Auto-Refresh:** Updates as user modifies plan
- **Collapse/Expand:** Minimize to see more canvas

### Cost Estimation Screen
- **Tier Selection:**
  - Radio buttons: Basic (₹1500/sqft), Standard (₹2000/sqft), Premium (₹3000/sqft)
- **Calculations:**
  - Total built-up area (auto-calculated from rooms)
  - Total cost = Area × Rate
- **Breakdown (Pie Chart or Table):**
  - Structure: 50%
  - Interiors: 20%
  - Electrical: 15%
  - Plumbing: 15%
- **Display:**
  - Large total cost number
  - Category breakdown with percentages
  - "Copy" or "Share" button

### Plan Report Screen
- **Summary Card:**
  - Plan name (editable)
  - Total area
  - Energy score with status
  - Cost estimate (with selected tier)
- **Sections:**
  - Issues & Suggestions (collapsible)
  - Cost Breakdown (collapsible)
- **Actions:**
  - "Export as JSON" button
  - "Export as PDF" button (optional)
  - "Save Plan" button
  - "Share" button

### Save/Load Screen
- **Saved Plans List:**
  - Each plan shows: name, date, thumbnail preview, area, energy score
  - Swipe to delete (or long-press menu)
- **Create New Plan:** Button at top
- **Load Plan:** Tap to open in designer
- **Empty State:** "No saved plans yet. Create your first plan!" with "New Plan" button

### Templates Screen
- **Template Cards:**
  - 1BHK (thumbnail preview, area estimate)
  - 2BHK (thumbnail preview, area estimate)
  - Small Office (thumbnail preview, area estimate)
- **Tap to Load:** Loads template into designer
- **Customizable:** User can modify after loading

### Settings Screen
- **User Mode:**
  - Guest mode (default, no login)
  - Email login (optional)
- **Preferences:**
  - Units (ft or m)
  - Grid size
  - Theme (Light/Dark)
- **About:** App version, help, privacy policy

---

## Key User Flows

### Flow 1: Create & Design a Floor Plan
1. User taps "New Plan" on Home Screen
2. Designer screen opens with empty grid
3. User taps "Add Room" button
4. Room type selection appears (Bedroom, Kitchen, etc.)
5. User selects room type
6. Room appears on canvas (default size, e.g., 12×12 ft)
7. User drags room to position, resizes via corner handles
8. Snap-to-grid snaps room to nearest grid intersection
9. User repeats steps 3–8 to add more rooms
10. Compass overlay shows room directions
11. Vastu panel updates automatically with energy score & issues
12. User reviews suggestions in Smart Suggestions panel
13. User adjusts room positions based on suggestions

### Flow 2: Estimate Cost
1. User taps "Cost" button in toolbar
2. Cost Estimation screen opens
3. User selects tier (Basic/Standard/Premium)
4. Total cost calculated and displayed
5. Breakdown shown (pie chart or table)
6. User taps "Back" or "Report" to continue

### Flow 3: Generate & Export Report
1. User taps "Report" button in toolbar
2. Plan Report screen opens with summary
3. User reviews energy score, issues, cost
4. User taps "Export as JSON" or "Export as PDF"
5. File is saved or shared
6. User can "Save Plan" to backend

### Flow 4: Load & Modify Saved Plan
1. User taps "My Plans" on Home Screen
2. Save/Load screen opens with list of saved plans
3. User taps a plan to load
4. Designer screen opens with loaded plan
5. User modifies rooms, reviews Vastu feedback
6. User taps "Save" to update plan

### Flow 5: Use Template
1. User taps "Browse Templates" on Home Screen
2. Templates screen opens
3. User taps a template (e.g., 1BHK)
4. Designer screen opens with template layout
5. User customizes rooms as needed
6. User saves as new plan

---

## Color Choices

### Brand Palette (PlanAura)
- **Primary Accent:** Teal/Cyan (#0a7ea4) – Energy, balance, calm
- **Background:** White (#ffffff) – Clean, minimalist
- **Surface:** Light Gray (#f5f5f5) – Cards, panels
- **Text Primary:** Dark Gray (#11181c) – Main content
- **Text Secondary:** Medium Gray (#687076) – Secondary info
- **Border:** Light Gray (#e5e7eb) – Dividers

### Semantic Colors (Vastu Feedback)
- **Success/Good:** Green (#22c55e) – Correct placements
- **Warning/Caution:** Yellow (#f59e0b) – Issues to review
- **Error/Bad:** Red (#ef4444) – Violations
- **Info:** Blue (#3b82f6) – Suggestions, hints

### Room Type Colors
- **Bedroom:** Blue (#3b82f6)
- **Kitchen:** Orange (#f97316)
- **Bathroom:** Green (#10b981)
- **Living Room:** Purple (#a855f7)
- **Office:** Gray (#6b7280)

### Dark Mode
- **Background:** Very Dark Gray (#151718)
- **Surface:** Dark Gray (#1e2022)
- **Text Primary:** Light Gray (#ecedee)
- **Text Secondary:** Medium Gray (#9ba1a6)
- **Border:** Dark Gray (#334155)
- **Semantic colors remain the same**

---

## Layout Principles

1. **Portrait Orientation (9:16):** All screens designed for vertical scrolling
2. **One-Handed Usage:** Buttons and interactive elements within thumb reach (bottom half of screen)
3. **Floating Action Buttons (FAB):** Primary actions (Add Room, New Plan) in bottom-right corner
4. **Bottom Panels:** Secondary controls (room properties, suggestions, cost) slide up from bottom
5. **Top Toolbar:** Navigation and quick toggles (compass, undo/redo, delete)
6. **Safe Area Handling:** Content respects notch, home indicator, and tab bar
7. **Minimalist Design:** Whitespace, clear hierarchy, no clutter
8. **Touch Targets:** Minimum 44×44 pt for interactive elements
9. **Feedback:** Visual & haptic feedback for all interactions (press states, haptics on success)

---

## Navigation Structure

```
Home Screen
├── New Plan → Designer Screen
├── Browse Templates → Templates Screen → Designer Screen
└── My Plans → Save/Load Screen → Designer Screen

Designer Screen
├── Room Properties Panel (side/bottom)
├── Vastu Analysis Panel (bottom)
├── Smart Suggestions Panel (bottom)
├── Cost Estimation Screen (modal/tab)
├── Plan Report Screen (modal/tab)
└── Settings (tab bar or menu)

Settings Screen
└── User preferences, theme, units
```

---

## Accessibility & Performance

- **Text Contrast:** All text meets WCAG AA standards (4.5:1 for body text)
- **Touch Targets:** Minimum 44×44 pt (iOS HIG standard)
- **Haptic Feedback:** Light feedback on interactions, no overuse
- **Performance:** Canvas rendering optimized for smooth drag/resize (60 FPS target)
- **Offline Support:** Plans cached locally; sync to backend optional
- **Dark Mode:** Full support with CSS variables and theme context

---

## Future Enhancements (Not MVP)

- 3D preview of floor plan
- AR house preview
- AI-powered layout optimization
- Architect marketplace integration
- Advanced Vastu/Feng Shui dataset
- Premium subscription features

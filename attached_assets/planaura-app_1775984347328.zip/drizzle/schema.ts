import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Plans table: Stores floor plans created by users
 */
export const plans = mysqlTable("plans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // Optional: for future user association
  name: varchar("name", { length: 255 }).notNull(),
  totalArea: int("totalArea").notNull().default(0), // in sqft
  vastuScore: int("vastuScore").notNull().default(0), // 0-100
  costEstimate: int("costEstimate").notNull().default(0), // in currency units
  costTier: varchar("costTier", { length: 50 }).default("standard"), // basic, standard, premium
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Plan = typeof plans.$inferSelect;
export type InsertPlan = typeof plans.$inferInsert;

/**
 * Rooms table: Stores individual rooms within a plan
 */
export const rooms = mysqlTable("rooms", {
  id: int("id").autoincrement().primaryKey(),
  planId: int("planId").notNull(), // Foreign key to plans
  roomType: varchar("roomType", { length: 50 }).notNull(), // bedroom, kitchen, bathroom, living_room, office
  x: int("x").notNull().default(0), // x coordinate in grid units
  y: int("y").notNull().default(0), // y coordinate in grid units
  width: int("width").notNull().default(12), // width in grid units
  height: int("height").notNull().default(12), // height in grid units
  direction: varchar("direction", { length: 10 }).default("N"), // N, NE, E, SE, S, SW, W, NW
  area: int("area").notNull().default(144), // calculated area in sqft
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Room = typeof rooms.$inferSelect;
export type InsertRoom = typeof rooms.$inferInsert;

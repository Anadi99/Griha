import React from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { useDesignerStore } from "@/lib/store";
import { useColors } from "@/hooks/use-colors";
import { optimizeLayout, applyOptimization } from "@/lib/ai-optimizer";

interface AIOptimizationPanelProps {
  onClose?: () => void;
}

export function AIOptimizationPanel({ onClose }: AIOptimizationPanelProps) {
  const colors = useColors();
  const store = useDesignerStore();
  const [optimization, setOptimization] = React.useState<ReturnType<typeof optimizeLayout> | null>(null);

  if (!store.currentPlan) {
    return (
      <View className="bg-surface p-4 border-t border-border">
        <Text className="text-muted text-center">No plan loaded</Text>
      </View>
    );
  }

  const handleOptimize = () => {
    const result = optimizeLayout(store.currentPlan!);
    setOptimization(result);
  };

  const handleApplyOptimization = () => {
    if (optimization) {
      const optimizedPlan = applyOptimization(store.currentPlan!, optimization.suggestions);
      store.loadPlan(optimizedPlan);
      store.calculateDirections();
      setOptimization(null);
    }
  };

  return (
    <ScrollView className="bg-surface border-t border-border max-h-96">
      <View className="p-4 gap-4">
        {!optimization ? (
          <>
            <Text className="text-foreground font-semibold text-sm">AI Layout Optimization</Text>
            <Text className="text-muted text-xs">
              Let AI analyze your floor plan and suggest optimal room placements based on Vastu principles and space efficiency.
            </Text>

            <Pressable
              onPress={handleOptimize}
              style={({ pressed }) => [
                {
                  paddingHorizontal: 12,
                  paddingVertical: 10,
                  borderRadius: 6,
                  backgroundColor: colors.primary,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <Text className="text-background font-semibold text-center">Analyze & Optimize</Text>
            </Pressable>
          </>
        ) : (
          <>
            {/* Optimization Results */}
            <View className="gap-3">
              <Text className="text-foreground font-semibold text-sm">Optimization Results</Text>

              {/* Score Improvement */}
              <View className="bg-background p-3 rounded-lg border border-success/30">
                <View className="flex-row items-center justify-between">
                  <Text className="text-muted text-xs">Current Score</Text>
                  <Text className="text-foreground font-bold">{optimization.originalScore}</Text>
                </View>
                <View className="flex-row items-center justify-between mt-2">
                  <Text className="text-muted text-xs">Optimized Score</Text>
                  <Text style={{ color: "#22c55e", fontWeight: "bold" }}>
                    {optimization.optimizedScore}
                  </Text>
                </View>
                <View className="flex-row items-center justify-between mt-2">
                  <Text className="text-muted text-xs">Improvement</Text>
                  <Text style={{ color: "#22c55e", fontWeight: "bold" }}>
                    +{optimization.improvement.toFixed(1)}%
                  </Text>
                </View>
              </View>

              {/* Summary */}
              <View className="bg-background p-3 rounded-lg">
                <Text className="text-foreground text-xs">{optimization.summary}</Text>
              </View>

              {/* Suggestions */}
              {optimization.suggestions.length > 0 && (
                <View className="gap-2">
                  <Text className="text-foreground font-semibold text-xs">Suggestions ({optimization.suggestions.length})</Text>
                  {optimization.suggestions.map((suggestion) => (
                    <View key={suggestion.id} className="bg-background p-2 rounded border border-border">
                      <Text className="text-foreground text-xs font-semibold">{suggestion.reason}</Text>
                      <Text className="text-muted text-xs mt-1">
                        Move from ({suggestion.currentPosition.x}, {suggestion.currentPosition.y}) to (
                        {suggestion.suggestedPosition.x}, {suggestion.suggestedPosition.y})
                      </Text>
                    </View>
                  ))}
                </View>
              )}

              {/* Action Buttons */}
              <View className="gap-2 mt-2">
                <Pressable
                  onPress={handleApplyOptimization}
                  style={({ pressed }) => [
                    {
                      paddingHorizontal: 12,
                      paddingVertical: 10,
                      borderRadius: 6,
                      backgroundColor: colors.primary,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text className="text-background font-semibold text-center text-sm">Apply Optimization</Text>
                </Pressable>

                <Pressable
                  onPress={() => setOptimization(null)}
                  style={({ pressed }) => [
                    {
                      paddingHorizontal: 12,
                      paddingVertical: 10,
                      borderRadius: 6,
                      backgroundColor: colors.border,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <Text className="text-foreground font-semibold text-center text-sm">Cancel</Text>
                </Pressable>
              </View>
            </View>
          </>
        )}
      </View>
    </ScrollView>
  );
}

import React from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { useDesignerStore, Room } from "@/lib/store";
import { useColors } from "@/hooks/use-colors";
import { cn } from "@/lib/utils";

const ROOM_TYPES: Array<Room["type"]> = ["bedroom", "kitchen", "bathroom", "living_room", "office"];
const ROOM_TYPE_LABELS: Record<Room["type"], string> = {
  bedroom: "Bedroom",
  kitchen: "Kitchen",
  bathroom: "Bathroom",
  living_room: "Living Room",
  office: "Office",
};

interface RoomPropertiesPanelProps {
  onClose?: () => void;
}

export function RoomPropertiesPanel({ onClose }: RoomPropertiesPanelProps) {
  const colors = useColors();
  const store = useDesignerStore();

  const selectedRoom = store.currentPlan?.rooms.find((r) => r.id === store.selectedRoomId);

  if (!selectedRoom) {
    return (
      <View className="bg-surface p-4 border-t border-border">
        <Text className="text-muted text-center">Select a room to edit properties</Text>
      </View>
    );
  }

  const handleRoomTypeChange = (type: Room["type"]) => {
    store.updateRoom(selectedRoom.id, { type });
  };

  const handleDimensionChange = (field: "width" | "height", value: number) => {
    store.updateRoom(selectedRoom.id, { [field]: Math.max(1, value) });
    store.calculateDirections();
  };

  const handlePositionChange = (field: "x" | "y", value: number) => {
    store.updateRoom(selectedRoom.id, { [field]: Math.max(0, value) });
    store.calculateDirections();
  };

  const handleDelete = () => {
    store.deleteRoom(selectedRoom.id);
  };

  return (
    <ScrollView className="bg-surface border-t border-border max-h-64">
      <View className="p-4 gap-4">
        {/* Room Type Selection */}
        <View className="gap-2">
          <Text className="text-foreground font-semibold text-sm">Room Type</Text>
          <View className="flex-row flex-wrap gap-2">
            {ROOM_TYPES.map((type) => (
              <Pressable
                key={type}
                onPress={() => handleRoomTypeChange(type)}
                style={({ pressed }) => [
                  {
                    paddingHorizontal: 12,
                    paddingVertical: 8,
                    borderRadius: 6,
                    backgroundColor: selectedRoom.type === type ? colors.primary : colors.background,
                    borderWidth: 1,
                    borderColor: colors.border,
                    opacity: pressed ? 0.7 : 1,
                  },
                ]}
              >
                <Text
                  className={cn(
                    "text-xs font-medium",
                    selectedRoom.type === type ? "text-background" : "text-foreground"
                  )}
                >
                  {ROOM_TYPE_LABELS[type]}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Position */}
        <View className="gap-2">
          <Text className="text-foreground font-semibold text-sm">Position (Grid Units)</Text>
          <View className="flex-row gap-2">
            <View className="flex-1">
              <Text className="text-muted text-xs mb-1">X</Text>
              <Pressable
                style={({ pressed }) => [
                  {
                    paddingHorizontal: 8,
                    paddingVertical: 6,
                    borderRadius: 4,
                    backgroundColor: colors.background,
                    borderWidth: 1,
                    borderColor: colors.border,
                    opacity: pressed ? 0.7 : 1,
                  },
                ]}
                onPress={() => handlePositionChange("x", selectedRoom.x - 1)}
              >
                <Text className="text-foreground text-xs">{selectedRoom.x}</Text>
              </Pressable>
            </View>
            <View className="flex-1">
              <Text className="text-muted text-xs mb-1">Y</Text>
              <Pressable
                style={({ pressed }) => [
                  {
                    paddingHorizontal: 8,
                    paddingVertical: 6,
                    borderRadius: 4,
                    backgroundColor: colors.background,
                    borderWidth: 1,
                    borderColor: colors.border,
                    opacity: pressed ? 0.7 : 1,
                  },
                ]}
                onPress={() => handlePositionChange("y", selectedRoom.y - 1)}
              >
                <Text className="text-foreground text-xs">{selectedRoom.y}</Text>
              </Pressable>
            </View>
          </View>
        </View>

        {/* Dimensions */}
        <View className="gap-2">
          <Text className="text-foreground font-semibold text-sm">Dimensions (Grid Units)</Text>
          <View className="flex-row gap-2">
            <View className="flex-1">
              <Text className="text-muted text-xs mb-1">Width</Text>
              <Pressable
                style={({ pressed }) => [
                  {
                    paddingHorizontal: 8,
                    paddingVertical: 6,
                    borderRadius: 4,
                    backgroundColor: colors.background,
                    borderWidth: 1,
                    borderColor: colors.border,
                    opacity: pressed ? 0.7 : 1,
                  },
                ]}
                onPress={() => handleDimensionChange("width", selectedRoom.width - 1)}
              >
                <Text className="text-foreground text-xs">{selectedRoom.width}</Text>
              </Pressable>
            </View>
            <View className="flex-1">
              <Text className="text-muted text-xs mb-1">Height</Text>
              <Pressable
                style={({ pressed }) => [
                  {
                    paddingHorizontal: 8,
                    paddingVertical: 6,
                    borderRadius: 4,
                    backgroundColor: colors.background,
                    borderWidth: 1,
                    borderColor: colors.border,
                    opacity: pressed ? 0.7 : 1,
                  },
                ]}
                onPress={() => handleDimensionChange("height", selectedRoom.height - 1)}
              >
                <Text className="text-foreground text-xs">{selectedRoom.height}</Text>
              </Pressable>
            </View>
          </View>
        </View>

        {/* Direction & Area */}
        <View className="flex-row gap-2">
          <View className="flex-1">
            <Text className="text-muted text-xs mb-1">Direction</Text>
            <View
              style={{
                paddingHorizontal: 8,
                paddingVertical: 6,
                borderRadius: 4,
                backgroundColor: colors.background,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <Text className="text-foreground text-xs font-semibold">{selectedRoom.direction}</Text>
            </View>
          </View>
          <View className="flex-1">
            <Text className="text-muted text-xs mb-1">Area (sqft)</Text>
            <View
              style={{
                paddingHorizontal: 8,
                paddingVertical: 6,
                borderRadius: 4,
                backgroundColor: colors.background,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <Text className="text-foreground text-xs font-semibold">{selectedRoom.area}</Text>
            </View>
          </View>
        </View>

        {/* Delete Button */}
        <Pressable
          onPress={handleDelete}
          style={({ pressed }) => [
            {
              paddingHorizontal: 12,
              paddingVertical: 10,
              borderRadius: 6,
              backgroundColor: "#ef4444",
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <Text className="text-background text-sm font-semibold text-center">Delete Room</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

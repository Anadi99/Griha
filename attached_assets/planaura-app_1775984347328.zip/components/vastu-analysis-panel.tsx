import React from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { useDesignerStore } from "@/lib/store";
import { useColors } from "@/hooks/use-colors";
import { analyzeVastu, getVastuScoreColor, getVastuScoreStatus } from "@/lib/vastu-engine";

interface VastuAnalysisPanelProps {
  onClose?: () => void;
}

export function VastuAnalysisPanel({ onClose }: VastuAnalysisPanelProps) {
  const colors = useColors();
  const store = useDesignerStore();

  if (!store.currentPlan) {
    return (
      <View className="bg-surface p-4 border-t border-border">
        <Text className="text-muted text-center">No plan loaded</Text>
      </View>
    );
  }

  const analysis = analyzeVastu(store.currentPlan);
  const scoreColor = getVastuScoreColor(analysis.score);
  const scoreStatus = getVastuScoreStatus(analysis.score);

  return (
    <ScrollView className="bg-surface border-t border-border max-h-80">
      <View className="p-4 gap-4">
        {/* Energy Score */}
        <View className="items-center gap-2">
          <Text className="text-foreground font-semibold text-sm">Energy Score</Text>
          <View
            style={{
              width: 120,
              height: 120,
              borderRadius: 60,
              backgroundColor: scoreColor,
              alignItems: "center",
              justifyContent: "center",
              opacity: 0.2,
              borderWidth: 2,
              borderColor: scoreColor,
            }}
          >
            <Text style={{ color: scoreColor, fontSize: 32, fontWeight: "bold" }}>
              {analysis.score}
            </Text>
          </View>
          <Text style={{ color: scoreColor, fontWeight: "bold" }}>{scoreStatus}</Text>
        </View>

        {/* Issues */}
        {analysis.issues.length > 0 && (
          <View className="gap-2">
            <Text className="text-foreground font-semibold text-sm">Issues ({analysis.issues.length})</Text>
            {analysis.issues.map((issue) => (
              <View
                key={issue.id}
                className="bg-background p-3 rounded-lg border border-error/30"
              >
                <View className="flex-row items-start gap-2">
                  <Text style={{ color: "#ef4444", fontSize: 16 }}>✕</Text>
                  <View className="flex-1">
                    <Text className="text-foreground text-xs font-semibold">{issue.message}</Text>
                    {issue.severity && (
                      <Text className="text-muted text-xs mt-1">
                        Severity: {issue.severity.charAt(0).toUpperCase() + issue.severity.slice(1)}
                      </Text>
                    )}
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Positives */}
        {analysis.positives.length > 0 && (
          <View className="gap-2">
            <Text className="text-foreground font-semibold text-sm">Good Placements ({analysis.positives.length})</Text>
            {analysis.positives.map((positive) => (
              <View
                key={positive.id}
                className="bg-background p-3 rounded-lg border border-success/30"
              >
                <View className="flex-row items-start gap-2">
                  <Text style={{ color: "#22c55e", fontSize: 16 }}>✓</Text>
                  <Text className="text-foreground text-xs flex-1">{positive.message}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Suggestions */}
        {analysis.suggestions.length > 0 && (
          <View className="gap-2">
            <Text className="text-foreground font-semibold text-sm">Suggestions ({analysis.suggestions.length})</Text>
            {analysis.suggestions.map((suggestion) => (
              <View
                key={suggestion.id}
                className="bg-background p-3 rounded-lg border border-warning/30"
              >
                <View className="flex-row items-start gap-2">
                  <Text style={{ color: "#f59e0b", fontSize: 16 }}>💡</Text>
                  <View className="flex-1">
                    <Text className="text-foreground text-xs">{suggestion.message}</Text>
                    {suggestion.priority && (
                      <Text className="text-muted text-xs mt-1">
                        Priority: {suggestion.priority.charAt(0).toUpperCase() + suggestion.priority.slice(1)}
                      </Text>
                    )}
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Empty State */}
        {analysis.issues.length === 0 && analysis.positives.length === 0 && (
          <View className="items-center py-4">
            <Text className="text-muted text-sm">Add rooms to see Vastu analysis</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

import React, { useRef, useEffect, useState } from "react";
import { View, PanResponder, GestureResponderEvent, PanResponderGestureState } from "react-native";
import Svg, { Rect, Text as SvgText, G, Line, Circle } from "react-native-svg";
import { useDesignerStore, Room } from "@/lib/store";
import { useColors } from "@/hooks/use-colors";

const GRID_UNIT_SIZE = 20; // pixels per grid unit
const ROOM_COLORS: Record<Room["type"], string> = {
  bedroom: "#3b82f6",
  kitchen: "#f97316",
  bathroom: "#10b981",
  living_room: "#a855f7",
  office: "#6b7280",
};

interface FloorPlanCanvasProps {
  width: number;
  height: number;
  onRoomSelect?: (roomId: string | null) => void;
}

export function FloorPlanCanvas({ width, height, onRoomSelect }: FloorPlanCanvasProps) {
  const colors = useColors();
  const store = useDesignerStore();
  const [canvasSize, setCanvasSize] = useState({ width, height });
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderMove: (evt: GestureResponderEvent, gestureState: PanResponderGestureState) => {
        // Handle pan
        store.setPan(store.panX + gestureState.dx, store.panY + gestureState.dy);
      },
    })
  ).current;

  if (!store.currentPlan) {
    return (
      <View className="flex-1 items-center justify-center bg-background">
        <SvgText fill={colors.muted} fontSize="14">
          No plan loaded
        </SvgText>
      </View>
    );
  }

  const svgWidth = canvasSize.width;
  const svgHeight = canvasSize.height;
  const gridSpacing = GRID_UNIT_SIZE * store.zoom;

  // Draw grid
  const gridLines = [];
  for (let x = 0; x < svgWidth; x += gridSpacing) {
    gridLines.push(
      <Line
        key={`v-${x}`}
        x1={x + store.panX}
        y1={0}
        x2={x + store.panX}
        y2={svgHeight}
        stroke={colors.border}
        strokeWidth="0.5"
      />
    );
  }
  for (let y = 0; y < svgHeight; y += gridSpacing) {
    gridLines.push(
      <Line
        key={`h-${y}`}
        x1={0}
        y1={y + store.panY}
        x2={svgWidth}
        y2={y + store.panY}
        stroke={colors.border}
        strokeWidth="0.5"
      />
    );
  }

  // Draw rooms
  const roomElements = store.currentPlan.rooms.map((room) => {
    const x = room.x * GRID_UNIT_SIZE * store.zoom + store.panX;
    const y = room.y * GRID_UNIT_SIZE * store.zoom + store.panY;
    const roomWidth = room.width * GRID_UNIT_SIZE * store.zoom;
    const roomHeight = room.height * GRID_UNIT_SIZE * store.zoom;
    const isSelected = store.selectedRoomId === room.id;
    const color = ROOM_COLORS[room.type];

    return (
      <G key={room.id} onPress={() => onRoomSelect?.(room.id)}>
        <Rect
          x={x}
          y={y}
          width={roomWidth}
          height={roomHeight}
          fill={color}
          fillOpacity={isSelected ? 0.3 : 0.1}
          stroke={isSelected ? color : colors.border}
          strokeWidth={isSelected ? 2 : 1}
        />
        {/* Room label */}
        <SvgText
          x={x + roomWidth / 2}
          y={y + roomHeight / 2}
          textAnchor="middle"
          fontSize="12"
          fill={colors.foreground}
          fontWeight="bold"
        >
          {room.type.replace("_", " ")}
        </SvgText>
        {/* Direction badge */}
        <SvgText
          x={x + 5}
          y={y + 15}
          fontSize="10"
          fill={color}
          fontWeight="bold"
        >
          {room.direction}
        </SvgText>
      </G>
    );
  });

  // Draw compass overlay (top-right)
  const compassSize = 60;
  const compassX = svgWidth - compassSize - 10;
  const compassY = 10;

  return (
    <View
      className="flex-1 bg-background"
      {...panResponder.panHandlers}
      onLayout={(e) => {
        setCanvasSize({
          width: e.nativeEvent.layout.width,
          height: e.nativeEvent.layout.height,
        });
      }}
    >
      <Svg width={svgWidth} height={svgHeight} viewBox={`0 0 ${svgWidth} ${svgHeight}`}>
        {/* Grid */}
        <G>{gridLines}</G>

        {/* Rooms */}
        <G>{roomElements}</G>

        {/* Compass */}
        <G>
          <Circle cx={compassX + compassSize / 2} cy={compassY + compassSize / 2} r={compassSize / 2} fill={colors.surface} stroke={colors.border} strokeWidth="1" />
          <SvgText x={compassX + compassSize / 2} y={compassY + 15} textAnchor="middle" fontSize="12" fill={colors.foreground} fontWeight="bold">
            N
          </SvgText>
          <SvgText x={compassX + compassSize - 5} y={compassY + compassSize / 2 + 5} textAnchor="end" fontSize="10" fill={colors.muted}>
            E
          </SvgText>
          <SvgText x={compassX + compassSize / 2} y={compassY + compassSize - 5} textAnchor="middle" fontSize="10" fill={colors.muted}>
            S
          </SvgText>
          <SvgText x={compassX + 5} y={compassY + compassSize / 2 + 5} fontSize="10" fill={colors.muted}>
            W
          </SvgText>
        </G>
      </Svg>
    </View>
  );
}

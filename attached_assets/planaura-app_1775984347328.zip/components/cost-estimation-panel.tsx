import React, { useState } from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { useDesignerStore, Plan } from "@/lib/store";
import { useColors } from "@/hooks/use-colors";
import { calculateCostEstimate, formatCost, getCostTierLabel } from "@/lib/cost-calculator";

interface CostEstimationPanelProps {
  onClose?: () => void;
}

export function CostEstimationPanel({ onClose }: CostEstimationPanelProps) {
  const colors = useColors();
  const store = useDesignerStore();
  const [selectedTier, setSelectedTier] = useState<"basic" | "standard" | "premium">(
    store.currentPlan?.costTier || "standard"
  );

  if (!store.currentPlan) {
    return (
      <View className="bg-surface p-4 border-t border-border">
        <Text className="text-muted text-center">No plan loaded</Text>
      </View>
    );
  }

  const estimate = calculateCostEstimate(store.currentPlan, selectedTier);

  const handleTierChange = (tier: "basic" | "standard" | "premium") => {
    setSelectedTier(tier);
    store.updateRoom(store.currentPlan!.id, { type: tier as any });
  };

  return (
    <ScrollView className="bg-surface border-t border-border max-h-80">
      <View className="p-4 gap-4">
        {/* Cost Tier Selection */}
        <View className="gap-2">
          <Text className="text-foreground font-semibold text-sm">Cost Tier</Text>
          <View className="gap-2">
            {(["basic", "standard", "premium"] as const).map((tier) => (
              <Pressable
                key={tier}
                onPress={() => handleTierChange(tier)}
                style={({ pressed }) => [
                  {
                    paddingHorizontal: 12,
                    paddingVertical: 10,
                    borderRadius: 6,
                    backgroundColor: selectedTier === tier ? colors.primary : colors.background,
                    borderWidth: 1,
                    borderColor: colors.border,
                    opacity: pressed ? 0.7 : 1,
                  },
                ]}
              >
                <View className="flex-row items-center justify-between">
                  <View>
                    <Text
                      className={selectedTier === tier ? "text-background font-semibold" : "text-foreground font-semibold"}
                    >
                      {getCostTierLabel(tier)}
                    </Text>
                    <Text className={selectedTier === tier ? "text-background/80 text-xs" : "text-muted text-xs"}>
                      {formatCost(estimate.ratePerSqft)}/sqft
                    </Text>
                  </View>
                </View>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Total Area */}
        <View className="bg-background p-3 rounded-lg border border-border">
          <Text className="text-muted text-xs mb-1">Total Built-up Area</Text>
          <Text className="text-foreground font-bold text-lg">{estimate.totalArea} sqft</Text>
        </View>

        {/* Total Cost */}
        <View className="bg-primary/10 p-4 rounded-lg border border-primary/30">
          <Text className="text-muted text-xs mb-1">Total Estimated Cost</Text>
          <Text style={{ color: colors.primary, fontSize: 28, fontWeight: "bold" }}>
            {formatCost(estimate.totalCost)}
          </Text>
        </View>

        {/* Cost Breakdown */}
        <View className="gap-2">
          <Text className="text-foreground font-semibold text-sm">Cost Breakdown</Text>
          <View className="gap-2">
            {[
              { label: "Structure", value: estimate.breakdown.structure, percentage: 50 },
              { label: "Interiors", value: estimate.breakdown.interiors, percentage: 20 },
              { label: "Electrical", value: estimate.breakdown.electrical, percentage: 15 },
              { label: "Plumbing", value: estimate.breakdown.plumbing, percentage: 15 },
            ].map((item) => (
              <View key={item.label} className="gap-1">
                <View className="flex-row items-center justify-between">
                  <Text className="text-foreground text-xs">{item.label}</Text>
                  <Text className="text-foreground font-semibold text-xs">
                    {formatCost(item.value)} ({item.percentage}%)
                  </Text>
                </View>
                <View
                  style={{
                    height: 6,
                    backgroundColor: colors.border,
                    borderRadius: 3,
                    overflow: "hidden",
                  }}
                >
                  <View
                    style={{
                      height: "100%",
                      width: `${item.percentage}%`,
                      backgroundColor: colors.primary,
                    }}
                  />
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Copy Button */}
        <Pressable
          style={({ pressed }) => [
            {
              paddingHorizontal: 12,
              paddingVertical: 10,
              borderRadius: 6,
              backgroundColor: colors.primary,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
          onPress={() => {
            const text = `Cost Estimate: ${formatCost(estimate.totalCost)}\nArea: ${estimate.totalArea} sqft\nTier: ${getCostTierLabel(selectedTier)}`;
            // TODO: Copy to clipboard
          }}
        >
          <Text className="text-background font-semibold text-center text-sm">Copy Estimate</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

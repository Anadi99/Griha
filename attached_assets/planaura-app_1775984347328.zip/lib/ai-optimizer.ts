import { Plan, Room } from "@/lib/store";

export interface OptimizationSuggestion {
  id: string;
  roomId: string;
  currentPosition: { x: number; y: number };
  suggestedPosition: { x: number; y: number };
  reason: string;
  improvementScore: number; // 0-100
}

export interface OptimizationResult {
  originalScore: number;
  optimizedScore: number;
  improvement: number; // percentage
  suggestions: OptimizationSuggestion[];
  summary: string;
}

/**
 * AI-powered layout optimization algorithm
 * Suggests optimal room placements based on Vastu principles and space efficiency
 */
export function optimizeLayout(plan: Plan): OptimizationResult {
  const suggestions: OptimizationSuggestion[] = [];
  let totalImprovement = 0;

  // Calculate original score
  const originalScore = plan.vastuScore;

  // Optimization rules
  const optimizations = [
    optimizeKitchenPlacement(plan),
    optimizeBedroomPlacement(plan),
    optimizeLivingRoomPlacement(plan),
    optimizeBathroomPlacement(plan),
    optimizeOfficePlacement(plan),
    optimizeSpaceEfficiency(plan),
  ];

  optimizations.forEach((opt) => {
    if (opt) {
      suggestions.push(opt);
      totalImprovement += opt.improvementScore;
    }
  });

  const optimizedScore = Math.min(100, originalScore + totalImprovement / suggestions.length);
  const improvement = ((optimizedScore - originalScore) / originalScore) * 100;

  return {
    originalScore,
    optimizedScore: Math.round(optimizedScore),
    improvement: Math.round(improvement),
    suggestions,
    summary: generateOptimizationSummary(suggestions, improvement),
  };
}

function optimizeKitchenPlacement(plan: Plan): OptimizationSuggestion | null {
  const kitchen = plan.rooms.find((r) => r.type === "kitchen");
  if (!kitchen) return null;

  // Kitchens should be in SE direction
  if (kitchen.direction !== "SE") {
    return {
      id: `opt_kitchen_${kitchen.id}`,
      roomId: kitchen.id,
      currentPosition: { x: kitchen.x, y: kitchen.y },
      suggestedPosition: { x: 15, y: 15 }, // SE position
      reason: "Kitchen should be in South-East direction for optimal Vastu alignment",
      improvementScore: 15,
    };
  }
  return null;
}

function optimizeBedroomPlacement(plan: Plan): OptimizationSuggestion | null {
  const bedroom = plan.rooms.find((r) => r.type === "bedroom");
  if (!bedroom) return null;

  // Bedrooms should be in SW direction
  if (bedroom.direction !== "SW") {
    return {
      id: `opt_bedroom_${bedroom.id}`,
      roomId: bedroom.id,
      currentPosition: { x: bedroom.x, y: bedroom.y },
      suggestedPosition: { x: 0, y: 15 }, // SW position
      reason: "Bedroom should be in South-West direction for peaceful energy",
      improvementScore: 12,
    };
  }
  return null;
}

function optimizeLivingRoomPlacement(plan: Plan): OptimizationSuggestion | null {
  const livingRoom = plan.rooms.find((r) => r.type === "living_room");
  if (!livingRoom) return null;

  // Living rooms should be in N or E direction
  if (!["N", "E", "NE"].includes(livingRoom.direction)) {
    return {
      id: `opt_living_${livingRoom.id}`,
      roomId: livingRoom.id,
      currentPosition: { x: livingRoom.x, y: livingRoom.y },
      suggestedPosition: { x: 0, y: 0 }, // NE position
      reason: "Living room should be in North or East direction for positive energy",
      improvementScore: 10,
    };
  }
  return null;
}

function optimizeBathroomPlacement(plan: Plan): OptimizationSuggestion | null {
  const bathroom = plan.rooms.find((r) => r.type === "bathroom");
  if (!bathroom) return null;

  // Bathrooms should avoid NE direction
  if (bathroom.direction === "NE") {
    return {
      id: `opt_bathroom_${bathroom.id}`,
      roomId: bathroom.id,
      currentPosition: { x: bathroom.x, y: bathroom.y },
      suggestedPosition: { x: 15, y: 0 }, // NW position
      reason: "Bathroom should avoid North-East direction",
      improvementScore: 8,
    };
  }
  return null;
}

function optimizeOfficePlacement(plan: Plan): OptimizationSuggestion | null {
  const office = plan.rooms.find((r) => r.type === "office");
  if (!office) return null;

  // Offices should be in N or E direction
  if (!["N", "E", "NE"].includes(office.direction)) {
    return {
      id: `opt_office_${office.id}`,
      roomId: office.id,
      currentPosition: { x: office.x, y: office.y },
      suggestedPosition: { x: 0, y: 0 }, // NE position
      reason: "Office should be in North or East direction for productivity",
      improvementScore: 10,
    };
  }
  return null;
}

function optimizeSpaceEfficiency(plan: Plan): OptimizationSuggestion | null {
  // Check if rooms are efficiently arranged (no large gaps)
  const avgRoomSize = plan.totalArea / plan.rooms.length;
  const unusedSpace = calculateUnusedSpace(plan);

  if (unusedSpace > avgRoomSize * 0.5) {
    return {
      id: "opt_space_efficiency",
      roomId: "",
      currentPosition: { x: 0, y: 0 },
      suggestedPosition: { x: 0, y: 0 },
      reason: "Rearrange rooms to reduce unused space and improve efficiency",
      improvementScore: 5,
    };
  }
  return null;
}

function calculateUnusedSpace(plan: Plan): number {
  // Simplified calculation - in production, use more sophisticated algorithms
  const totalBoundingArea = 30 * 30; // Assume 30x30 grid
  return totalBoundingArea - plan.totalArea;
}

function generateOptimizationSummary(suggestions: OptimizationSuggestion[], improvement: number): string {
  if (suggestions.length === 0) {
    return "Your floor plan is already well-optimized!";
  }

  const roomTypes = new Set(suggestions.map((s) => s.roomId));
  return `AI suggests repositioning ${roomTypes.size} room(s) to improve energy score by ${improvement.toFixed(1)}%.`;
}

/**
 * Apply optimization suggestions to a plan
 */
export function applyOptimization(plan: Plan, suggestions: OptimizationSuggestion[]): Plan {
  const updatedRooms = plan.rooms.map((room) => {
    const suggestion = suggestions.find((s) => s.roomId === room.id);
    if (suggestion) {
      return {
        ...room,
        x: suggestion.suggestedPosition.x,
        y: suggestion.suggestedPosition.y,
      };
    }
    return room;
  });

  return {
    ...plan,
    rooms: updatedRooms,
    updatedAt: new Date(),
  };
}

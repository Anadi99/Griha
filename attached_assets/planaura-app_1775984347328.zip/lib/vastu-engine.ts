import { Room, Plan } from "@/lib/store";

export interface VastuIssue {
  id: string;
  roomId: string;
  roomType: Room["type"];
  severity: "high" | "medium" | "low";
  message: string;
}

export interface VastuPositive {
  id: string;
  roomId: string;
  roomType: Room["type"];
  message: string;
}

export interface VastuSuggestion {
  id: string;
  roomId: string;
  priority: "high" | "medium" | "low";
  message: string;
  suggestedDirection?: Room["direction"];
}

export interface VastuAnalysis {
  score: number; // 0-100
  issues: VastuIssue[];
  positives: VastuPositive[];
  suggestions: VastuSuggestion[];
}

// Vastu rules mapping room types to preferred directions
const PREFERRED_DIRECTIONS: Record<Room["type"], Room["direction"][]> = {
  bedroom: ["SW", "W", "NW"],
  kitchen: ["SE", "S"],
  bathroom: ["NW", "N"],
  living_room: ["N", "E", "NE"],
  office: ["N", "E", "NE"],
};

const AVOID_DIRECTIONS: Record<Room["type"], Room["direction"][]> = {
  bedroom: ["N", "NE"],
  kitchen: ["N", "NW"],
  bathroom: ["NE", "E"],
  living_room: ["S", "SW"],
  office: ["S", "SW"],
};

/**
 * Calculate Vastu analysis for a floor plan
 */
export function analyzeVastu(plan: Plan): VastuAnalysis {
  const issues: VastuIssue[] = [];
  const positives: VastuPositive[] = [];
  const suggestions: VastuSuggestion[] = [];

  // Analyze each room
  plan.rooms.forEach((room) => {
    const preferred = PREFERRED_DIRECTIONS[room.type];
    const avoid = AVOID_DIRECTIONS[room.type];

    // Check if room is in preferred direction
    if (preferred.includes(room.direction)) {
      positives.push({
        id: `pos_${room.id}`,
        roomId: room.id,
        roomType: room.type,
        message: `${room.type.replace("_", " ")} is well-placed in ${room.direction} direction`,
      });
    } else if (avoid.includes(room.direction)) {
      // Room is in avoid direction
      issues.push({
        id: `issue_${room.id}_avoid`,
        roomId: room.id,
        roomType: room.type,
        severity: "high",
        message: `${room.type.replace("_", " ")} should avoid ${room.direction} direction`,
      });

      // Add suggestion
      const suggestedDir = preferred[0];
      suggestions.push({
        id: `sug_${room.id}_move`,
        roomId: room.id,
        priority: "high",
        message: `Move ${room.type.replace("_", " ")} to ${suggestedDir} direction for better Vastu alignment`,
        suggestedDirection: suggestedDir,
      });
    } else {
      // Room is in neutral direction
      suggestions.push({
        id: `sug_${room.id}_improve`,
        roomId: room.id,
        priority: "medium",
        message: `Consider moving ${room.type.replace("_", " ")} to ${preferred[0]} direction for optimal energy`,
        suggestedDirection: preferred[0],
      });
    }
  });

  // Check for room placement conflicts
  const roomsByType = new Map<Room["type"], Room[]>();
  plan.rooms.forEach((room) => {
    if (!roomsByType.has(room.type)) {
      roomsByType.set(room.type, []);
    }
    roomsByType.get(room.type)!.push(room);
  });

  // Check for multiple kitchens or bedrooms (not ideal)
  if (roomsByType.get("kitchen")?.length! > 1) {
    issues.push({
      id: "issue_multiple_kitchens",
      roomId: "",
      roomType: "kitchen",
      severity: "medium",
      message: "Multiple kitchens detected - typically only one is recommended",
    });
  }

  // Calculate energy score
  let score = 100;

  // Deduct points for each issue
  issues.forEach((issue) => {
    if (issue.severity === "high") score -= 15;
    else if (issue.severity === "medium") score -= 10;
    else score -= 5;
  });

  // Add points for positive placements
  score += positives.length * 5;

  // Ensure score is within 0-100
  score = Math.max(0, Math.min(100, score));

  return {
    score: Math.round(score),
    issues,
    positives,
    suggestions,
  };
}

/**
 * Get color for Vastu score
 */
export function getVastuScoreColor(score: number): string {
  if (score >= 80) return "#22c55e"; // Green - Excellent
  if (score >= 50) return "#f59e0b"; // Yellow - Good
  return "#ef4444"; // Red - Needs Improvement
}

/**
 * Get Vastu score status text
 */
export function getVastuScoreStatus(score: number): string {
  if (score >= 80) return "Excellent";
  if (score >= 50) return "Good";
  return "Needs Improvement";
}

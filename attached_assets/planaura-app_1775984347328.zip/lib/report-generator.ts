import { Plan } from "@/lib/store";
import { analyzeVastu } from "@/lib/vastu-engine";
import { calculateCostEstimate, formatCost } from "@/lib/cost-calculator";

export interface PlanReport {
  planName: string;
  createdAt: string;
  totalArea: number;
  totalRooms: number;
  energyScore: number;
  energyStatus: string;
  costEstimate: number;
  costTier: string;
  issues: string[];
  positives: string[];
  suggestions: string[];
}

export function generatePlanReport(plan: Plan): PlanReport {
  const vastu = analyzeVastu(plan);
  const cost = calculateCostEstimate(plan, plan.costTier);

  return {
    planName: plan.name,
    createdAt: plan.createdAt.toISOString(),
    totalArea: plan.totalArea,
    totalRooms: plan.rooms.length,
    energyScore: vastu.score,
    energyStatus: vastu.score >= 80 ? "Excellent" : vastu.score >= 50 ? "Good" : "Needs Improvement",
    costEstimate: cost.totalCost,
    costTier: plan.costTier,
    issues: vastu.issues.map((i) => i.message),
    positives: vastu.positives.map((p) => p.message),
    suggestions: vastu.suggestions.map((s) => s.message),
  };
}

export function exportReportAsJSON(plan: Plan): string {
  const report = generatePlanReport(plan);
  return JSON.stringify(report, null, 2);
}

export function exportPlanAsJSON(plan: Plan): string {
  return JSON.stringify(
    {
      name: plan.name,
      rooms: plan.rooms,
      totalArea: plan.totalArea,
      vastuScore: plan.vastuScore,
      costEstimate: plan.costEstimate,
      costTier: plan.costTier,
      createdAt: plan.createdAt.toISOString(),
      updatedAt: plan.updatedAt.toISOString(),
    },
    null,
    2
  );
}

export interface Architect {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialization: string[];
  experience: number; // years
  rating: number; // 0-5
  reviews: number;
  location: string;
  portfolio: string[];
  hourlyRate: number;
  availability: boolean;
}

export interface Contractor {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialization: string[]; // e.g., "Electrical", "Plumbing", "Carpentry"
  experience: number;
  rating: number;
  reviews: number;
  location: string;
  completedProjects: number;
  averageProjectCost: number;
  availability: boolean;
}

export interface Material {
  id: string;
  name: string;
  category: "flooring" | "paint" | "tiles" | "wood" | "metal" | "glass" | "other";
  description: string;
  pricePerUnit: number;
  unit: "sqft" | "piece" | "meter" | "kg" | "liter";
  supplier: string;
  rating: number;
  inStock: boolean;
  image: string;
  specifications: Record<string, string>;
}

export interface Supplier {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  materials: string[]; // Material IDs
  rating: number;
  reviews: number;
  deliveryTime: number; // days
  minOrderValue: number;
}

// Mock data for marketplace
export const MOCK_ARCHITECTS: Architect[] = [
  {
    id: "arch_001",
    name: "Rajesh Kumar",
    email: "rajesh@architects.com",
    phone: "+91-9876543210",
    specialization: ["Residential", "Commercial", "Vastu"],
    experience: 12,
    rating: 4.8,
    reviews: 45,
    location: "Mumbai",
    portfolio: ["Project1", "Project2"],
    hourlyRate: 2000,
    availability: true,
  },
  {
    id: "arch_002",
    name: "Priya Sharma",
    email: "priya@architects.com",
    phone: "+91-9876543211",
    specialization: ["Interior Design", "Vastu", "Sustainable"],
    experience: 8,
    rating: 4.6,
    reviews: 32,
    location: "Bangalore",
    portfolio: ["Project3", "Project4"],
    hourlyRate: 1800,
    availability: true,
  },
];

export const MOCK_CONTRACTORS: Contractor[] = [
  {
    id: "cont_001",
    name: "Electrical Works Ltd",
    email: "contact@electricalworks.com",
    phone: "+91-9876543220",
    specialization: ["Electrical", "Solar"],
    experience: 15,
    rating: 4.7,
    reviews: 58,
    location: "Delhi",
    completedProjects: 120,
    averageProjectCost: 150000,
    availability: true,
  },
  {
    id: "cont_002",
    name: "Plumbing Solutions",
    email: "contact@plumbingsolutions.com",
    phone: "+91-9876543221",
    specialization: ["Plumbing", "Water Systems"],
    experience: 10,
    rating: 4.5,
    reviews: 42,
    location: "Pune",
    completedProjects: 85,
    averageProjectCost: 80000,
    availability: true,
  },
];

export const MOCK_MATERIALS: Material[] = [
  {
    id: "mat_001",
    name: "Premium Ceramic Tiles",
    category: "tiles",
    description: "High-quality ceramic tiles for flooring and walls",
    pricePerUnit: 350,
    unit: "sqft",
    supplier: "Tile Masters",
    rating: 4.6,
    inStock: true,
    image: "https://via.placeholder.com/200",
    specifications: {
      size: "60x60cm",
      finish: "Matte",
      durability: "High",
    },
  },
  {
    id: "mat_002",
    name: "Wooden Flooring",
    category: "flooring",
    description: "Premium wooden flooring with natural finish",
    pricePerUnit: 500,
    unit: "sqft",
    supplier: "Wood Experts",
    rating: 4.8,
    inStock: true,
    image: "https://via.placeholder.com/200",
    specifications: {
      wood: "Oak",
      thickness: "18mm",
      finish: "Natural",
    },
  },
  {
    id: "mat_003",
    name: "Interior Paint",
    category: "paint",
    description: "Eco-friendly interior paint with excellent coverage",
    pricePerUnit: 450,
    unit: "liter",
    supplier: "Paint World",
    rating: 4.5,
    inStock: true,
    image: "https://via.placeholder.com/200",
    specifications: {
      coverage: "12 sqft/liter",
      finish: "Matte",
      eco: "Yes",
    },
  },
];

export const MOCK_SUPPLIERS: Supplier[] = [
  {
    id: "sup_001",
    name: "Tile Masters",
    email: "contact@tilemasters.com",
    phone: "+91-9876543230",
    location: "Mumbai",
    materials: ["mat_001"],
    rating: 4.6,
    reviews: 120,
    deliveryTime: 3,
    minOrderValue: 10000,
  },
  {
    id: "sup_002",
    name: "Wood Experts",
    email: "contact@woodexperts.com",
    phone: "+91-9876543231",
    location: "Bangalore",
    materials: ["mat_002"],
    rating: 4.8,
    reviews: 95,
    deliveryTime: 5,
    minOrderValue: 15000,
  },
];

/**
 * Search architects by specialization
 */
export function searchArchitects(specialization?: string): Architect[] {
  if (!specialization) return MOCK_ARCHITECTS;
  return MOCK_ARCHITECTS.filter((a) => a.specialization.includes(specialization));
}

/**
 * Search contractors by specialization
 */
export function searchContractors(specialization?: string): Contractor[] {
  if (!specialization) return MOCK_CONTRACTORS;
  return MOCK_CONTRACTORS.filter((c) => c.specialization.includes(specialization));
}

/**
 * Search materials by category
 */
export function searchMaterials(category?: string): Material[] {
  if (!category) return MOCK_MATERIALS;
  return MOCK_MATERIALS.filter((m) => m.category === category);
}

/**
 * Get supplier details
 */
export function getSupplier(supplierId: string): Supplier | undefined {
  return MOCK_SUPPLIERS.find((s) => s.id === supplierId);
}

/**
 * Calculate material cost for project
 */
export function calculateMaterialCost(materials: Material[], quantities: Record<string, number>): number {
  return materials.reduce((total, material) => {
    const quantity = quantities[material.id] || 0;
    return total + material.pricePerUnit * quantity;
  }, 0);
}

/**
 * Get top-rated professionals
 */
export function getTopRatedArchitects(limit: number = 5): Architect[] {
  return MOCK_ARCHITECTS.sort((a, b) => b.rating - a.rating).slice(0, limit);
}

export function getTopRatedContractors(limit: number = 5): Contractor[] {
  return MOCK_CONTRACTORS.sort((a, b) => b.rating - a.rating).slice(0, limit);
}

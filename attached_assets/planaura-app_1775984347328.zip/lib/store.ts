import { create } from "zustand";

export interface Room {
  id: string;
  type: "bedroom" | "kitchen" | "bathroom" | "living_room" | "office";
  x: number; // grid units
  y: number; // grid units
  width: number; // grid units
  height: number; // grid units
  direction: "N" | "NE" | "E" | "SE" | "S" | "SW" | "W" | "NW";
  area: number; // sqft
}

export interface Plan {
  id: string;
  name: string;
  rooms: Room[];
  totalArea: number;
  vastuScore: number;
  costEstimate: number;
  costTier: "basic" | "standard" | "premium";
  createdAt: Date;
  updatedAt: Date;
}

interface DesignerStore {
  // Current plan
  currentPlan: Plan | null;
  selectedRoomId: string | null;
  gridSize: number; // pixels per grid unit
  zoom: number; // zoom level (1 = 100%)
  panX: number;
  panY: number;

  // Actions
  createNewPlan: (name: string) => void;
  loadPlan: (plan: Plan) => void;
  addRoom: (room: Omit<Room, "id">) => void;
  updateRoom: (id: string, updates: Partial<Room>) => void;
  deleteRoom: (id: string) => void;
  selectRoom: (id: string | null) => void;
  setZoom: (zoom: number) => void;
  setPan: (x: number, y: number) => void;
  calculateTotalArea: () => number;
  calculateDirections: () => void;
}

export const useDesignerStore = create<DesignerStore>((set: any, get: any) => ({
  currentPlan: null,
  selectedRoomId: null,
  gridSize: 20, // 20 pixels per grid unit
  zoom: 1,
  panX: 0,
  panY: 0,

  createNewPlan: (name: string) => {
    set({
      currentPlan: {
        id: `plan_${Date.now()}`,
        name,
        rooms: [],
        totalArea: 0,
        vastuScore: 0,
        costEstimate: 0,
        costTier: "standard",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      selectedRoomId: null,
    });
  },

  loadPlan: (plan: Plan) => {
    set({
      currentPlan: plan,
      selectedRoomId: null,
    });
  },

  addRoom: (room: Omit<Room, "id">) => {
    set((state: DesignerStore) => {
      if (!state.currentPlan) return state;

      const newRoom: Room = {
        ...room,
        id: `room_${Date.now()}_${Math.random()}`,
      };

      const updatedPlan = {
        ...state.currentPlan,
        rooms: [...state.currentPlan.rooms, newRoom],
        updatedAt: new Date(),
      };

      // Recalculate total area
      const totalArea = updatedPlan.rooms.reduce((sum: number, r: Room) => sum + r.area, 0);
      updatedPlan.totalArea = totalArea;

      return {
        currentPlan: updatedPlan,
      };
    });
  },

  updateRoom: (id: string, updates: Partial<Room>) => {
    set((state: DesignerStore) => {
      if (!state.currentPlan) return state;

      const updatedRooms = state.currentPlan.rooms.map((room: Room) =>
        room.id === id ? { ...room, ...updates } : room
      );

      const updatedPlan = {
        ...state.currentPlan,
        rooms: updatedRooms,
        updatedAt: new Date(),
      };

      // Recalculate total area
      const totalArea = updatedPlan.rooms.reduce((sum: number, r: Room) => sum + r.area, 0);
      updatedPlan.totalArea = totalArea;

      return {
        currentPlan: updatedPlan,
      };
    });
  },

  deleteRoom: (id: string) => {
    set((state: DesignerStore) => {
      if (!state.currentPlan) return state;

      const updatedRooms = state.currentPlan.rooms.filter((room: Room) => room.id !== id);

      const updatedPlan = {
        ...state.currentPlan,
        rooms: updatedRooms,
        updatedAt: new Date(),
      };

      // Recalculate total area
      const totalArea = updatedPlan.rooms.reduce((sum: number, r: Room) => sum + r.area, 0);
      updatedPlan.totalArea = totalArea;

      return {
        currentPlan: updatedPlan,
        selectedRoomId: state.selectedRoomId === id ? null : state.selectedRoomId,
      };
    });
  },

  selectRoom: (id: string | null) => {
    set({ selectedRoomId: id });
  },

  setZoom: (zoom: number) => {
    set({ zoom: Math.max(0.5, Math.min(3, zoom)) });
  },

  setPan: (x: number, y: number) => {
    set({ panX: x, panY: y });
  },

  calculateTotalArea: () => {
    const state = get();
    if (!state.currentPlan) return 0;
    return state.currentPlan.rooms.reduce((sum: number, room: Room) => sum + room.area, 0);
  },

  calculateDirections: () => {
    set((state: DesignerStore) => {
      if (!state.currentPlan) return state;

      const updatedRooms = state.currentPlan.rooms.map((room: Room) => {
        // Calculate centroid
        const centerX = room.x + room.width / 2;
        const centerY = room.y + room.height / 2;

        // Calculate angle from center (0,0) to room centroid
        const angle = Math.atan2(centerY, centerX) * (180 / Math.PI);

        // Normalize angle to 0-360
        const normalizedAngle = (angle + 360) % 360;

        // Determine direction based on angle
        let direction: Room["direction"] = "N";
        if (normalizedAngle >= 337.5 || normalizedAngle < 22.5) direction = "N";
        else if (normalizedAngle >= 22.5 && normalizedAngle < 67.5) direction = "NE";
        else if (normalizedAngle >= 67.5 && normalizedAngle < 112.5) direction = "E";
        else if (normalizedAngle >= 112.5 && normalizedAngle < 157.5) direction = "SE";
        else if (normalizedAngle >= 157.5 && normalizedAngle < 202.5) direction = "S";
        else if (normalizedAngle >= 202.5 && normalizedAngle < 247.5) direction = "SW";
        else if (normalizedAngle >= 247.5 && normalizedAngle < 292.5) direction = "W";
        else if (normalizedAngle >= 292.5 && normalizedAngle < 337.5) direction = "NW";

        return { ...room, direction };
      });

      return {
        currentPlan: {
          ...state.currentPlan,
          rooms: updatedRooms,
        },
      };
    });
  },
}));

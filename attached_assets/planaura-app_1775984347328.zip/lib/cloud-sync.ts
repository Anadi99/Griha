import { Plan } from "@/lib/store";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface CloudUser {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
}

export interface CloudPlan {
  id: string;
  userId: string;
  name: string;
  data: Plan;
  sharedWith: string[]; // User IDs
  version: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface SyncStatus {
  isSyncing: boolean;
  lastSyncTime: Date | null;
  pendingChanges: number;
  syncError: string | null;
}

const CLOUD_STORAGE_KEY = "planaura_cloud_plans";
const SYNC_STATUS_KEY = "planaura_sync_status";
const USER_KEY = "planaura_user";

/**
 * Initialize cloud sync
 */
export async function initializeCloudSync(): Promise<void> {
  try {
    const status = await AsyncStorage.getItem(SYNC_STATUS_KEY);
    if (!status) {
      await AsyncStorage.setItem(
        SYNC_STATUS_KEY,
        JSON.stringify({
          isSyncing: false,
          lastSyncTime: null,
          pendingChanges: 0,
          syncError: null,
        })
      );
    }
  } catch (error) {
    console.error("Failed to initialize cloud sync:", error);
  }
}

/**
 * Save plan to cloud
 */
export async function savePlanToCloud(plan: Plan, userId: string): Promise<CloudPlan> {
  try {
    const cloudPlan: CloudPlan = {
      id: plan.id,
      userId,
      name: plan.name,
      data: plan,
      sharedWith: [],
      version: 1,
      createdAt: plan.createdAt,
      updatedAt: new Date(),
    };

    // Save to local storage first (offline support)
    const plans = await AsyncStorage.getItem(CLOUD_STORAGE_KEY);
    const plansList: CloudPlan[] = plans ? JSON.parse(plans) : [];
    const existingIndex = plansList.findIndex((p) => p.id === plan.id);

    if (existingIndex >= 0) {
      plansList[existingIndex] = { ...cloudPlan, version: plansList[existingIndex].version + 1 };
    } else {
      plansList.push(cloudPlan);
    }

    await AsyncStorage.setItem(CLOUD_STORAGE_KEY, JSON.stringify(plansList));

    // TODO: Sync with backend API
    // await api.plans.saveToCloud(cloudPlan);

    return cloudPlan;
  } catch (error) {
    console.error("Failed to save plan to cloud:", error);
    throw error;
  }
}

/**
 * Load plans from cloud
 */
export async function loadPlansFromCloud(userId: string): Promise<CloudPlan[]> {
  try {
    const plans = await AsyncStorage.getItem(CLOUD_STORAGE_KEY);
    const plansList: CloudPlan[] = plans ? JSON.parse(plans) : [];

    // Filter plans for current user
    return plansList.filter((p) => p.userId === userId);
  } catch (error) {
    console.error("Failed to load plans from cloud:", error);
    return [];
  }
}

/**
 * Share plan with other users
 */
export async function sharePlan(planId: string, userEmails: string[]): Promise<void> {
  try {
    const plans = await AsyncStorage.getItem(CLOUD_STORAGE_KEY);
    const plansList: CloudPlan[] = plans ? JSON.parse(plans) : [];

    const plan = plansList.find((p) => p.id === planId);
    if (plan) {
      plan.sharedWith = [...new Set([...plan.sharedWith, ...userEmails])];
      await AsyncStorage.setItem(CLOUD_STORAGE_KEY, JSON.stringify(plansList));

      // TODO: Notify shared users via API
      // await api.plans.sharePlan(planId, userEmails);
    }
  } catch (error) {
    console.error("Failed to share plan:", error);
    throw error;
  }
}

/**
 * Get sync status
 */
export async function getSyncStatus(): Promise<SyncStatus> {
  try {
    const status = await AsyncStorage.getItem(SYNC_STATUS_KEY);
    return status ? JSON.parse(status) : getDefaultSyncStatus();
  } catch (error) {
    console.error("Failed to get sync status:", error);
    return getDefaultSyncStatus();
  }
}

/**
 * Update sync status
 */
export async function updateSyncStatus(updates: Partial<SyncStatus>): Promise<void> {
  try {
    const currentStatus = await getSyncStatus();
    const newStatus = { ...currentStatus, ...updates };
    await AsyncStorage.setItem(SYNC_STATUS_KEY, JSON.stringify(newStatus));
  } catch (error) {
    console.error("Failed to update sync status:", error);
  }
}

/**
 * Sync all plans with cloud
 */
export async function syncAllPlans(userId: string): Promise<void> {
  try {
    await updateSyncStatus({ isSyncing: true, syncError: null });

    // Get local plans
    const localPlans = await loadPlansFromCloud(userId);

    // TODO: Sync with backend
    // const cloudPlans = await api.plans.listByUser(userId);
    // Merge and resolve conflicts
    // Update local storage with merged data

    await updateSyncStatus({
      isSyncing: false,
      lastSyncTime: new Date(),
      pendingChanges: 0,
    });
  } catch (error) {
    console.error("Failed to sync plans:", error);
    await updateSyncStatus({
      isSyncing: false,
      syncError: error instanceof Error ? error.message : "Unknown error",
    });
  }
}

/**
 * Enable offline mode
 */
export async function enableOfflineMode(): Promise<void> {
  try {
    await updateSyncStatus({ isSyncing: false });
  } catch (error) {
    console.error("Failed to enable offline mode:", error);
  }
}

function getDefaultSyncStatus(): SyncStatus {
  return {
    isSyncing: false,
    lastSyncTime: null,
    pendingChanges: 0,
    syncError: null,
  };
}

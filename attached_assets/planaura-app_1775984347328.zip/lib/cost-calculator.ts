import { Plan } from "@/lib/store";

export interface CostBreakdown {
  structure: number;
  interiors: number;
  electrical: number;
  plumbing: number;
  total: number;
}

export interface CostEstimate {
  tier: "basic" | "standard" | "premium";
  ratePerSqft: number;
  totalArea: number;
  totalCost: number;
  breakdown: CostBreakdown;
}

// Cost rates per square foot (in currency units, e.g., ₹)
const COST_RATES: Record<"basic" | "standard" | "premium", number> = {
  basic: 1500,
  standard: 2000,
  premium: 3000,
};

// Cost breakdown percentages
const COST_BREAKDOWN_PERCENTAGES = {
  structure: 0.5, // 50%
  interiors: 0.2, // 20%
  electrical: 0.15, // 15%
  plumbing: 0.15, // 15%
};

/**
 * Calculate cost estimate for a floor plan
 */
export function calculateCostEstimate(
  plan: Plan,
  tier: "basic" | "standard" | "premium" = "standard"
): CostEstimate {
  const totalArea = plan.totalArea || 0;
  const ratePerSqft = COST_RATES[tier];
  const totalCost = totalArea * ratePerSqft;

  const breakdown: CostBreakdown = {
    structure: Math.round(totalCost * COST_BREAKDOWN_PERCENTAGES.structure),
    interiors: Math.round(totalCost * COST_BREAKDOWN_PERCENTAGES.interiors),
    electrical: Math.round(totalCost * COST_BREAKDOWN_PERCENTAGES.electrical),
    plumbing: Math.round(totalCost * COST_BREAKDOWN_PERCENTAGES.plumbing),
    total: Math.round(totalCost),
  };

  return {
    tier,
    ratePerSqft,
    totalArea,
    totalCost: Math.round(totalCost),
    breakdown,
  };
}

/**
 * Format cost as currency string
 */
export function formatCost(cost: number, currency: string = "₹"): string {
  return `${currency}${cost.toLocaleString("en-IN")}`;
}

/**
 * Get cost tier label
 */
export function getCostTierLabel(tier: "basic" | "standard" | "premium"): string {
  const labels: Record<"basic" | "standard" | "premium", string> = {
    basic: "Basic",
    standard: "Standard",
    premium: "Premium",
  };
  return labels[tier];
}

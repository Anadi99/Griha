import { Room, Plan } from "@/lib/store";

export interface DesignSuggestion {
  id: string;
  roomId: string;
  roomType: Room["type"];
  category: "furniture" | "color" | "material" | "lighting";
  suggestion: string;
  description: string;
  estimatedCost: number;
  priority: "high" | "medium" | "low";
}

export interface DesignRecommendation {
  roomId: string;
  roomType: Room["type"];
  suggestions: DesignSuggestion[];
  totalEstimatedCost: number;
  designStyle: string;
}

// Design recommendations by room type
const DESIGN_RECOMMENDATIONS: Record<Room["type"], DesignRecommendation> = {
  bedroom: {
    roomId: "",
    roomType: "bedroom",
    suggestions: [
      {
        id: "bed_furniture",
        roomId: "",
        roomType: "bedroom",
        category: "furniture",
        suggestion: "King-size bed with premium mattress",
        description: "Provides comfort and luxury for restful sleep",
        estimatedCost: 45000,
        priority: "high",
      },
      {
        id: "bed_color",
        roomId: "",
        roomType: "bedroom",
        category: "color",
        suggestion: "Soft pastel colors (cream, light blue, lavender)",
        description: "Promotes relaxation and peaceful sleep",
        estimatedCost: 8000,
        priority: "high",
      },
      {
        id: "bed_lighting",
        roomId: "",
        roomType: "bedroom",
        category: "lighting",
        suggestion: "Warm LED lighting with dimmer control",
        description: "Creates ambient lighting for sleep",
        estimatedCost: 5000,
        priority: "medium",
      },
      {
        id: "bed_material",
        roomId: "",
        roomType: "bedroom",
        category: "material",
        suggestion: "Wooden flooring with carpet",
        description: "Warm and comfortable underfoot",
        estimatedCost: 12000,
        priority: "medium",
      },
    ],
    totalEstimatedCost: 70000,
    designStyle: "Modern Minimalist",
  },
  kitchen: {
    roomId: "",
    roomType: "kitchen",
    suggestions: [
      {
        id: "kitchen_furniture",
        roomId: "",
        roomType: "kitchen",
        category: "furniture",
        suggestion: "Modular kitchen with stainless steel appliances",
        description: "Efficient and durable kitchen setup",
        estimatedCost: 150000,
        priority: "high",
      },
      {
        id: "kitchen_color",
        roomId: "",
        roomType: "kitchen",
        category: "color",
        suggestion: "White and light gray with accent colors",
        description: "Makes kitchen feel spacious and clean",
        estimatedCost: 10000,
        priority: "high",
      },
      {
        id: "kitchen_lighting",
        roomId: "",
        roomType: "kitchen",
        category: "lighting",
        suggestion: "Bright LED lights with under-cabinet lighting",
        description: "Ensures good visibility for cooking",
        estimatedCost: 8000,
        priority: "high",
      },
      {
        id: "kitchen_material",
        roomId: "",
        roomType: "kitchen",
        category: "material",
        suggestion: "Granite countertops with ceramic tiles",
        description: "Durable and easy to clean",
        estimatedCost: 25000,
        priority: "medium",
      },
    ],
    totalEstimatedCost: 193000,
    designStyle: "Contemporary",
  },
  bathroom: {
    roomId: "",
    roomType: "bathroom",
    suggestions: [
      {
        id: "bath_furniture",
        roomId: "",
        roomType: "bathroom",
        category: "furniture",
        suggestion: "Modern vanity with storage and premium fixtures",
        description: "Combines style with functionality",
        estimatedCost: 35000,
        priority: "high",
      },
      {
        id: "bath_color",
        roomId: "",
        roomType: "bathroom",
        category: "color",
        suggestion: "Soft whites and light blues",
        description: "Creates spa-like atmosphere",
        estimatedCost: 6000,
        priority: "medium",
      },
      {
        id: "bath_lighting",
        roomId: "",
        roomType: "bathroom",
        category: "lighting",
        suggestion: "Waterproof LED lights with exhaust fan",
        description: "Ensures safety and ventilation",
        estimatedCost: 4000,
        priority: "high",
      },
      {
        id: "bath_material",
        roomId: "",
        roomType: "bathroom",
        category: "material",
        suggestion: "Ceramic tiles with anti-slip coating",
        description: "Safe and easy to maintain",
        estimatedCost: 15000,
        priority: "high",
      },
    ],
    totalEstimatedCost: 60000,
    designStyle: "Spa-Inspired",
  },
  living_room: {
    roomId: "",
    roomType: "living_room",
    suggestions: [
      {
        id: "living_furniture",
        roomId: "",
        roomType: "living_room",
        category: "furniture",
        suggestion: "Modular sofa with coffee table and entertainment unit",
        description: "Comfortable seating and entertainment setup",
        estimatedCost: 80000,
        priority: "high",
      },
      {
        id: "living_color",
        roomId: "",
        roomType: "living_room",
        category: "color",
        suggestion: "Warm neutrals with accent wall",
        description: "Creates welcoming and sophisticated ambiance",
        estimatedCost: 12000,
        priority: "medium",
      },
      {
        id: "living_lighting",
        roomId: "",
        roomType: "living_room",
        category: "lighting",
        suggestion: "Combination of ceiling lights and floor lamps",
        description: "Provides flexible lighting options",
        estimatedCost: 8000,
        priority: "medium",
      },
      {
        id: "living_material",
        roomId: "",
        roomType: "living_room",
        category: "material",
        suggestion: "Wooden flooring with area rug",
        description: "Warm and inviting aesthetic",
        estimatedCost: 20000,
        priority: "medium",
      },
    ],
    totalEstimatedCost: 120000,
    designStyle: "Contemporary Comfort",
  },
  office: {
    roomId: "",
    roomType: "office",
    suggestions: [
      {
        id: "office_furniture",
        roomId: "",
        roomType: "office",
        category: "furniture",
        suggestion: "Ergonomic desk and chair with storage",
        description: "Supports productivity and comfort",
        estimatedCost: 40000,
        priority: "high",
      },
      {
        id: "office_color",
        roomId: "",
        roomType: "office",
        category: "color",
        suggestion: "Light colors with green accents",
        description: "Promotes focus and reduces stress",
        estimatedCost: 7000,
        priority: "medium",
      },
      {
        id: "office_lighting",
        roomId: "",
        roomType: "office",
        category: "lighting",
        suggestion: "Bright LED lights with natural light access",
        description: "Reduces eye strain and boosts productivity",
        estimatedCost: 6000,
        priority: "high",
      },
      {
        id: "office_material",
        roomId: "",
        roomType: "office",
        category: "material",
        suggestion: "Wooden flooring with cork mat",
        description: "Comfortable and professional appearance",
        estimatedCost: 10000,
        priority: "medium",
      },
    ],
    totalEstimatedCost: 63000,
    designStyle: "Professional Modern",
  },
};

/**
 * Generate design suggestions for a room
 */
export function generateDesignSuggestions(room: Room): DesignSuggestion[] {
  const recommendations = DESIGN_RECOMMENDATIONS[room.type];
  return recommendations.suggestions.map((s) => ({
    ...s,
    roomId: room.id,
  }));
}

/**
 * Generate design recommendations for entire plan
 */
export function generatePlanDesignRecommendations(plan: Plan): DesignRecommendation[] {
  return plan.rooms.map((room) => {
    const baseRecommendation = DESIGN_RECOMMENDATIONS[room.type];
    return {
      roomId: room.id,
      roomType: room.type,
      suggestions: generateDesignSuggestions(room),
      totalEstimatedCost: baseRecommendation.totalEstimatedCost,
      designStyle: baseRecommendation.designStyle,
    };
  });
}

/**
 * Calculate total design budget for plan
 */
export function calculateDesignBudget(recommendations: DesignRecommendation[]): number {
  return recommendations.reduce((sum, rec) => sum + rec.totalEstimatedCost, 0);
}

/**
 * Get design suggestions by category
 */
export function filterSuggestionsByCategory(
  suggestions: DesignSuggestion[],
  category: "furniture" | "color" | "material" | "lighting"
): DesignSuggestion[] {
  return suggestions.filter((s) => s.category === category);
}

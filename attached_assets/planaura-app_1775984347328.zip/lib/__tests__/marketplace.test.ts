import { describe, it, expect } from "vitest";
import {
  searchArchitects,
  searchContractors,
  searchMaterials,
  getTopRatedArchitects,
  getTopRatedContractors,
  calculateMaterialCost,
  MOCK_ARCHITECTS,
  MOCK_CONTRACTORS,
  MOCK_MATERIALS,
} from "../marketplace";

describe("Marketplace", () => {
  describe("Architects", () => {
    it("should return all architects when no specialization filter", () => {
      const result = searchArchitects();
      expect(result.length).toBeGreaterThan(0);
      expect(result).toEqual(MOCK_ARCHITECTS);
    });

    it("should filter architects by specialization", () => {
      const result = searchArchitects("Vastu");
      expect(result.length).toBeGreaterThan(0);
      result.forEach((arch) => {
        expect(arch.specialization).toContain("Vastu");
      });
    });

    it("should return top-rated architects", () => {
      const result = getTopRatedArchitects(2);
      expect(result.length).toBeLessThanOrEqual(2);
      if (result.length > 1) {
        expect(result[0].rating).toBeGreaterThanOrEqual(result[1].rating);
      }
    });
  });

  describe("Contractors", () => {
    it("should return all contractors when no specialization filter", () => {
      const result = searchContractors();
      expect(result.length).toBeGreaterThan(0);
      expect(result).toEqual(MOCK_CONTRACTORS);
    });

    it("should filter contractors by specialization", () => {
      const result = searchContractors("Electrical");
      expect(result.length).toBeGreaterThan(0);
      result.forEach((cont) => {
        expect(cont.specialization).toContain("Electrical");
      });
    });

    it("should return top-rated contractors", () => {
      const result = getTopRatedContractors(2);
      expect(result.length).toBeLessThanOrEqual(2);
      if (result.length > 1) {
        expect(result[0].rating).toBeGreaterThanOrEqual(result[1].rating);
      }
    });
  });

  describe("Materials", () => {
    it("should return all materials when no category filter", () => {
      const result = searchMaterials();
      expect(result.length).toBeGreaterThan(0);
      expect(result).toEqual(MOCK_MATERIALS);
    });

    it("should filter materials by category", () => {
      const result = searchMaterials("tiles");
      expect(result.length).toBeGreaterThan(0);
      result.forEach((mat) => {
        expect(mat.category).toBe("tiles");
      });
    });

    it("should calculate material cost correctly", () => {
      const materials = MOCK_MATERIALS.slice(0, 2);
      const quantities = {
        [materials[0].id]: 100,
        [materials[1].id]: 50,
      };
      const cost = calculateMaterialCost(materials, quantities);
      const expected = materials[0].pricePerUnit * 100 + materials[1].pricePerUnit * 50;
      expect(cost).toBe(expected);
    });

    it("should handle zero quantities", () => {
      const materials = MOCK_MATERIALS.slice(0, 1);
      const quantities = { [materials[0].id]: 0 };
      const cost = calculateMaterialCost(materials, quantities);
      expect(cost).toBe(0);
    });
  });
});

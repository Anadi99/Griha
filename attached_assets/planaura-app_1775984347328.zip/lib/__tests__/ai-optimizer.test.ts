import { describe, it, expect } from "vitest";
import { optimizeLayout, applyOptimization } from "../ai-optimizer";
import { Plan, Room } from "../store";

describe("AI Optimizer", () => {
  const mockPlan = {
    id: "test_plan",
    name: "Test Plan",
    rooms: [
      {
        id: "room_1",
        type: "kitchen",
        x: 0,
        y: 0,
        width: 12,
        height: 12,
        direction: "N",
        area: 144,
      },
      {
        id: "room_2",
        type: "bedroom",
        x: 12,
        y: 0,
        width: 12,
        height: 12,
        direction: "E",
        area: 144,
      },
    ],
    totalArea: 288,
    vastuScore: 50,
    costEstimate: 576000,
    costTier: "standard" as const,
    createdAt: new Date(),
    updatedAt: new Date(),
  } as Plan;

  it("should generate optimization suggestions", () => {
    const result = optimizeLayout(mockPlan);
    expect(result).toBeDefined();
    expect(result.suggestions.length).toBeGreaterThan(0);
  });

  it("should improve energy score", () => {
    const result = optimizeLayout(mockPlan);
    expect(result.optimizedScore).toBeGreaterThanOrEqual(result.originalScore);
  });

  it("should apply optimization suggestions", () => {
    const result = optimizeLayout(mockPlan);
    const optimizedPlan = applyOptimization(mockPlan, result.suggestions);
    expect(optimizedPlan.rooms.length).toBe(mockPlan.rooms.length);
  });

  it("should generate summary text", () => {
    const result = optimizeLayout(mockPlan);
    expect(result.summary).toBeDefined();
    expect(result.summary.length).toBeGreaterThan(0);
  });

  it("should calculate improvement percentage", () => {
    const result = optimizeLayout(mockPlan);
    expect(result.improvement).toBeGreaterThanOrEqual(0);
    expect(result.improvement).toBeLessThanOrEqual(100);
  });
});

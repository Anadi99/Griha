import { ScrollView, Text, View, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();

  const handleGetStarted = () => {
    router.push("/(tabs)/designer");
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1 gap-8">
          {/* Hero Section */}
          <View className="items-center gap-2 mt-8">
            <Text className="text-4xl font-bold text-foreground">PlanAura</Text>
            <Text className="text-base text-muted text-center">
              AI-Assisted Floor Plan & Vastu Design
            </Text>
          </View>

          {/* Feature Cards */}
          <View className="gap-4">
            <View className="bg-surface rounded-2xl p-6 border border-border">
              <Text className="text-lg font-semibold text-foreground mb-2">🎨 Floor Plan Designer</Text>
              <Text className="text-sm text-muted leading-relaxed">
                Create beautiful floor plans with an intuitive grid-based canvas. Add, edit, and arrange rooms effortlessly.
              </Text>
            </View>

            <View className="bg-surface rounded-2xl p-6 border border-border">
              <Text className="text-lg font-semibold text-foreground mb-2">✨ Vastu Analysis</Text>
              <Text className="text-sm text-muted leading-relaxed">
                Get real-time Vastu energy scoring and smart suggestions to optimize your floor plan.
              </Text>
            </View>

            <View className="bg-surface rounded-2xl p-6 border border-border">
              <Text className="text-lg font-semibold text-foreground mb-2">💰 Cost Estimation</Text>
              <Text className="text-sm text-muted leading-relaxed">
                Calculate construction costs with detailed breakdown across multiple tiers.
              </Text>
            </View>

            <View className="bg-surface rounded-2xl p-6 border border-border">
              <Text className="text-lg font-semibold text-foreground mb-2">☁️ Cloud Sync</Text>
              <Text className="text-sm text-muted leading-relaxed">
                Save your plans to the cloud and access them from any device.
              </Text>
            </View>

            <View className="bg-surface rounded-2xl p-6 border border-border">
              <Text className="text-lg font-semibold text-foreground mb-2">🤖 AI Optimization</Text>
              <Text className="text-sm text-muted leading-relaxed">
                Get AI-powered layout suggestions and interior design recommendations.
              </Text>
            </View>

            <View className="bg-surface rounded-2xl p-6 border border-border">
              <Text className="text-lg font-semibold text-foreground mb-2">🏗️ Marketplace</Text>
              <Text className="text-sm text-muted leading-relaxed">
                Connect with architects, contractors, and material suppliers.
              </Text>
            </View>
          </View>

          {/* CTA Button */}
          <View className="items-center gap-4 mt-8">
            <Pressable
              onPress={handleGetStarted}
              style={({ pressed }) => [
                {
                  paddingHorizontal: 32,
                  paddingVertical: 14,
                  borderRadius: 28,
                  backgroundColor: colors.primary,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <Text className="text-background font-bold text-lg">Get Started</Text>
            </Pressable>

            <Text className="text-xs text-muted">Start designing your perfect floor plan</Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

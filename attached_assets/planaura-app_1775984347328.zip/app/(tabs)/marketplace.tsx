import React, { useState } from "react";
import { View, Text, ScrollView, Pressable, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  searchArchitects,
  searchContractors,
  getTopRatedArchitects,
  getTopRatedContractors,
  MOCK_MATERIALS,
} from "@/lib/marketplace";

type Tab = "architects" | "contractors" | "materials";

export default function MarketplaceScreen() {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<Tab>("architects");

  const architects = getTopRatedArchitects(5);
  const contractors = getTopRatedContractors(5);

  return (
    <ScreenContainer className="flex-1" containerClassName="bg-background">
      {/* Header */}
      <View className="bg-surface border-b border-border px-4 py-3">
        <Text className="text-foreground font-bold text-lg">Marketplace</Text>
        <Text className="text-muted text-xs">Connect with professionals</Text>
      </View>

      {/* Tab Navigation */}
      <View className="flex-row bg-surface border-b border-border">
        {(["architects", "contractors", "materials"] as const).map((tab) => (
          <Pressable
            key={tab}
            onPress={() => setActiveTab(tab)}
            className={`flex-1 py-3 border-b-2 ${
              activeTab === tab ? "border-primary" : "border-transparent"
            }`}
          >
            <Text
              className={`text-center font-semibold text-xs ${
                activeTab === tab ? "text-primary" : "text-muted"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* Content */}
      <ScrollView className="flex-1">
        <View className="p-4 gap-4">
          {activeTab === "architects" && (
            <>
              <Text className="text-foreground font-semibold text-sm">Top Architects</Text>
              {architects.map((architect) => (
                <View
                  key={architect.id}
                  className="bg-surface rounded-lg p-4 border border-border gap-2"
                >
                  <View className="flex-row items-start justify-between">
                    <View className="flex-1">
                      <Text className="text-foreground font-bold">{architect.name}</Text>
                      <Text className="text-muted text-xs">{architect.specialization.join(", ")}</Text>
                    </View>
                    <View className="items-center">
                      <Text style={{ color: colors.primary, fontWeight: "bold" }}>
                        {architect.rating}★
                      </Text>
                      <Text className="text-muted text-xs">({architect.reviews})</Text>
                    </View>
                  </View>
                  <View className="flex-row items-center justify-between text-xs">
                    <Text className="text-muted">
                      {architect.experience} years • {architect.location}
                    </Text>
                    <Text className="text-primary font-semibold">₹{architect.hourlyRate}/hr</Text>
                  </View>
                  <Pressable
                    style={({ pressed }) => [
                      {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 4,
                        backgroundColor: colors.primary,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Text className="text-background font-semibold text-center text-xs">
                      Contact
                    </Text>
                  </Pressable>
                </View>
              ))}
            </>
          )}

          {activeTab === "contractors" && (
            <>
              <Text className="text-foreground font-semibold text-sm">Top Contractors</Text>
              {contractors.map((contractor) => (
                <View
                  key={contractor.id}
                  className="bg-surface rounded-lg p-4 border border-border gap-2"
                >
                  <View className="flex-row items-start justify-between">
                    <View className="flex-1">
                      <Text className="text-foreground font-bold">{contractor.name}</Text>
                      <Text className="text-muted text-xs">{contractor.specialization.join(", ")}</Text>
                    </View>
                    <View className="items-center">
                      <Text style={{ color: colors.primary, fontWeight: "bold" }}>
                        {contractor.rating}★
                      </Text>
                      <Text className="text-muted text-xs">({contractor.reviews})</Text>
                    </View>
                  </View>
                  <View className="flex-row items-center justify-between text-xs">
                    <Text className="text-muted">
                      {contractor.completedProjects} projects • {contractor.location}
                    </Text>
                    <Text className="text-primary font-semibold">
                      ₹{contractor.averageProjectCost.toLocaleString()}
                    </Text>
                  </View>
                  <Pressable
                    style={({ pressed }) => [
                      {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 4,
                        backgroundColor: colors.primary,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Text className="text-background font-semibold text-center text-xs">
                      Contact
                    </Text>
                  </Pressable>
                </View>
              ))}
            </>
          )}

          {activeTab === "materials" && (
            <>
              <Text className="text-foreground font-semibold text-sm">Popular Materials</Text>
              {MOCK_MATERIALS.map((material) => (
                <View
                  key={material.id}
                  className="bg-surface rounded-lg p-4 border border-border gap-2"
                >
                  <View className="flex-row items-start justify-between">
                    <View className="flex-1">
                      <Text className="text-foreground font-bold">{material.name}</Text>
                      <Text className="text-muted text-xs">{material.description}</Text>
                    </View>
                    <View className="items-center">
                      <Text style={{ color: colors.primary, fontWeight: "bold" }}>
                        {material.rating}★
                      </Text>
                    </View>
                  </View>
                  <View className="flex-row items-center justify-between text-xs">
                    <Text className="text-muted">{material.supplier}</Text>
                    <Text className="text-primary font-semibold">
                      ₹{material.pricePerUnit}/{material.unit}
                    </Text>
                  </View>
                  <View
                    className={`px-2 py-1 rounded text-center ${
                      material.inStock
                        ? "bg-success/20"
                        : "bg-error/20"
                    }`}
                  >
                    <Text className={`text-xs font-semibold ${
                      material.inStock ? "text-success" : "text-error"
                    }`}>
                      {material.inStock ? "In Stock" : "Out of Stock"}
                    </Text>
                  </View>
                  <Pressable
                    style={({ pressed }) => [
                      {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 4,
                        backgroundColor: colors.primary,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Text className="text-background font-semibold text-center text-xs">
                      Add to Quote
                    </Text>
                  </Pressable>
                </View>
              ))}
            </>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

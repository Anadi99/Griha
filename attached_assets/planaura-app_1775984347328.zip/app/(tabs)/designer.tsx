import React, { useState } from "react";
import { View, Text, Pressable, Modal } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { FloorPlanCanvas } from "@/components/floor-plan-canvas";
import { RoomPropertiesPanel } from "@/components/room-properties-panel";
import { useDesignerStore, Room } from "@/lib/store";
import { useColors } from "@/hooks/use-colors";

const ROOM_TYPES: Array<Room["type"]> = ["bedroom", "kitchen", "bathroom", "living_room", "office"];
const ROOM_TYPE_LABELS: Record<Room["type"], string> = {
  bedroom: "Bedroom",
  kitchen: "Kitchen",
  bathroom: "Bathroom",
  living_room: "Living Room",
  office: "Office",
};

export default function DesignerScreen() {
  const colors = useColors();
  const store = useDesignerStore();
  const [showRoomTypeModal, setShowRoomTypeModal] = useState(false);
  const [showPropertiesPanel, setShowPropertiesPanel] = useState(false);
  const [canvasWidth, setCanvasWidth] = useState(0);
  const [canvasHeight, setCanvasHeight] = useState(0);

  React.useEffect(() => {
    if (!store.currentPlan) {
      store.createNewPlan("My Floor Plan");
    }
  }, []);

  const handleAddRoom = (roomType: Room["type"]) => {
    store.addRoom({
      type: roomType,
      x: 0,
      y: 0,
      width: 12,
      height: 12,
      direction: "N",
      area: 144,
    });
    store.calculateDirections();
    setShowRoomTypeModal(false);
  };

  const handleRoomSelect = (roomId: string | null) => {
    store.selectRoom(roomId);
    if (roomId) {
      setShowPropertiesPanel(true);
    }
  };

  const handleZoom = (direction: "in" | "out") => {
    const newZoom = direction === "in" ? store.zoom * 1.2 : store.zoom / 1.2;
    store.setZoom(newZoom);
  };

  if (!store.currentPlan) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground text-lg">Loading...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="flex-1" containerClassName="bg-background">
      <View className="bg-surface border-b border-border px-4 py-3 flex-row items-center justify-between">
        <View>
          <Text className="text-foreground font-bold text-lg">{store.currentPlan.name}</Text>
          <Text className="text-muted text-xs">Area: {store.currentPlan.totalArea} sqft</Text>
        </View>
        <Pressable
          style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          onPress={() => setShowPropertiesPanel(!showPropertiesPanel)}
        >
          <Text className="text-primary font-semibold">Info</Text>
        </Pressable>
      </View>

      <View
        className="flex-1 bg-background"
        onLayout={(e) => {
          setCanvasWidth(e.nativeEvent.layout.width);
          setCanvasHeight(e.nativeEvent.layout.height - 120);
        }}
      >
        {canvasWidth > 0 && canvasHeight > 0 && (
          <FloorPlanCanvas
            width={canvasWidth}
            height={canvasHeight}
            onRoomSelect={handleRoomSelect}
          />
        )}
      </View>

      <View className="bg-surface border-t border-border px-3 py-2 flex-row items-center justify-between gap-2">
        <View className="flex-row gap-1">
          <Pressable
            style={({ pressed }) => [
              {
                paddingHorizontal: 8,
                paddingVertical: 6,
                borderRadius: 4,
                backgroundColor: colors.primary,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
            onPress={() => handleZoom("out")}
          >
            <Text className="text-background text-xs font-semibold">−</Text>
          </Pressable>
          <View
            style={{
              paddingHorizontal: 8,
              paddingVertical: 6,
              borderRadius: 4,
              backgroundColor: colors.background,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <Text className="text-foreground text-xs font-semibold">{Math.round(store.zoom * 100)}%</Text>
          </View>
          <Pressable
            style={({ pressed }) => [
              {
                paddingHorizontal: 8,
                paddingVertical: 6,
                borderRadius: 4,
                backgroundColor: colors.primary,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
            onPress={() => handleZoom("in")}
          >
            <Text className="text-background text-xs font-semibold">+</Text>
          </Pressable>
        </View>

        <Pressable
          style={({ pressed }) => [
            {
              paddingHorizontal: 12,
              paddingVertical: 8,
              borderRadius: 6,
              backgroundColor: colors.primary,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
          onPress={() => setShowRoomTypeModal(true)}
        >
          <Text className="text-background text-xs font-semibold">+ Room</Text>
        </Pressable>

        {store.selectedRoomId && (
          <Pressable
            style={({ pressed }) => [
              {
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderRadius: 6,
                backgroundColor: "#ef4444",
                opacity: pressed ? 0.8 : 1,
              },
            ]}
            onPress={() => {
              store.deleteRoom(store.selectedRoomId!);
              store.selectRoom(null);
            }}
          >
            <Text className="text-background text-xs font-semibold">Delete</Text>
          </Pressable>
        )}
      </View>

      <Modal
        visible={showRoomTypeModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowRoomTypeModal(false)}
      >
        <View className="flex-1 bg-black/50 items-center justify-center">
          <View className="bg-surface rounded-lg p-6 w-80 gap-4">
            <Text className="text-foreground font-bold text-lg">Select Room Type</Text>
            <View className="gap-2">
              {ROOM_TYPES.map((type) => (
                <Pressable
                  key={type}
                  style={({ pressed }) => [
                    {
                      paddingHorizontal: 12,
                      paddingVertical: 10,
                      borderRadius: 6,
                      backgroundColor: colors.primary,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                  onPress={() => handleAddRoom(type)}
                >
                  <Text className="text-background font-semibold text-center">{ROOM_TYPE_LABELS[type]}</Text>
                </Pressable>
              ))}
            </View>
            <Pressable
              style={({ pressed }) => [
                {
                  paddingHorizontal: 12,
                  paddingVertical: 10,
                  borderRadius: 6,
                  backgroundColor: colors.border,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              onPress={() => setShowRoomTypeModal(false)}
            >
              <Text className="text-foreground font-semibold text-center">Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      {showPropertiesPanel && <RoomPropertiesPanel onClose={() => setShowPropertiesPanel(false)} />}
    </ScreenContainer>
  );
}
